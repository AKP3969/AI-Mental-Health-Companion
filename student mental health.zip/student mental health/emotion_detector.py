"""
Advanced Text-Based Emotion Detection Module
Handles text-based emotion detection using multiple NLP techniques
"""

import re
import numpy as np
import json
import pickle
from collections import defaultdict
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# Core NLP libraries
from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import emot

# Advanced NLP libraries
try:
    from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
    import torch
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    print("Transformers not available. Using fallback methods.")

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import classification_report
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("Scikit-learn not available. Using rule-based methods.")

try:
    import spacy
    SPACY_AVAILABLE = True
except ImportError:
    SPACY_AVAILABLE = False
    print("SpaCy not available. Using basic text processing.")

class EmotionDetector:
    def __init__(self, model_type='ensemble'):
        """
        Initialize the emotion detector with specified model type
        
        Args:
            model_type: 'ensemble', 'transformers', 'ml', 'rule_based', or 'hybrid'
        """
        self.model_type = model_type
        self.vader_analyzer = SentimentIntensityAnalyzer()
        
        # Initialize SpaCy if available
        self.nlp = None
        if SPACY_AVAILABLE:
            try:
                self.nlp = spacy.load("en_core_web_sm")
            except OSError:
                print("SpaCy English model not found. Install with: python -m spacy download en_core_web_sm")
        
        # Initialize transformer models
        self.transformer_models = {}
        if TRANSFORMERS_AVAILABLE:
            self._load_transformer_models()
        
        # Initialize ML models
        self.ml_models = {}
        self.vectorizer = None
        if SKLEARN_AVAILABLE:
            self._initialize_ml_models()
        
        # Enhanced emotion keywords with weights
        self.emotion_keywords = self._load_emotion_keywords()
        
        # Emotion intensity modifiers
        self.intensity_modifiers = {
            'very': 1.5, 'extremely': 2.0, 'super': 1.8, 'really': 1.3,
            'quite': 1.2, 'somewhat': 0.8, 'slightly': 0.6, 'a bit': 0.7,
            'totally': 1.6, 'completely': 1.7, 'absolutely': 1.8
        }
        
        # Negation words
        self.negation_words = {
            'not', 'no', 'never', 'none', 'nothing', 'nobody', 'nowhere',
            'neither', 'nor', 'cannot', "can't", "won't", "don't", "didn't",
            "isn't", "aren't", "wasn't", "weren't", "hasn't", "haven't"
        }
        
        # Contextual emotion patterns
        self.context_patterns = self._load_context_patterns()
        
        # Load pre-trained models
        self._load_pretrained_models()
    
    def _load_emotion_keywords(self):
        """Load comprehensive emotion keywords with weights"""
        return {
            'happy': {
                'words': ['happy', 'joy', 'excited', 'cheerful', 'delighted', 'pleased', 'content', 'satisfied', 
                         'ecstatic', 'thrilled', 'elated', 'blissful', 'euphoric', 'jubilant', 'gleeful', 'merry'],
                'weight': 1.0,
                'intensifiers': ['overjoyed', 'thrilled', 'ecstatic', 'elated', 'blissful']
            },
            'sad': {
                'words': ['sad', 'depressed', 'down', 'blue', 'melancholy', 'gloomy', 'unhappy', 'miserable',
                         'sorrowful', 'dejected', 'despondent', 'crestfallen', 'disheartened', 'forlorn', 'woeful'],
                'weight': 1.0,
                'intensifiers': ['devastated', 'heartbroken', 'crushed', 'shattered', 'desolate']
            },
            'angry': {
                'words': ['angry', 'mad', 'furious', 'irritated', 'annoyed', 'rage', 'frustrated', 'livid',
                         'enraged', 'incensed', 'outraged', 'indignant', 'wrathful', 'fuming', 'seething'],
                'weight': 1.0,
                'intensifiers': ['livid', 'furious', 'enraged', 'incensed', 'outraged']
            },
            'fear': {
                'words': ['afraid', 'scared', 'fearful', 'terrified', 'anxious', 'worried', 'nervous', 'panic',
                         'alarmed', 'frightened', 'petrified', 'horrified', 'apprehensive', 'uneasy', 'jittery'],
                'weight': 1.0,
                'intensifiers': ['terrified', 'petrified', 'horrified', 'paralyzed', 'frozen']
            },
            'surprise': {
                'words': ['surprised', 'shocked', 'amazed', 'astonished', 'startled', 'bewildered', 'stunned',
                         'flabbergasted', 'astounded', 'dumbfounded', 'thunderstruck', 'gobsmacked'],
                'weight': 1.0,
                'intensifiers': ['flabbergasted', 'astounded', 'dumbfounded', 'thunderstruck']
            },
            'disgust': {
                'words': ['disgusted', 'revolted', 'sickened', 'repulsed', 'nauseated', 'appalled', 'repugnant',
                         'abhorrent', 'loathsome', 'detestable', 'odious', 'vile'],
                'weight': 1.0,
                'intensifiers': ['revolted', 'sickened', 'nauseated', 'appalled', 'abhorrent']
            },
            'neutral': {
                'words': ['okay', 'fine', 'normal', 'alright', 'so-so', 'meh', 'whatever', 'indifferent',
                         'apathetic', 'unconcerned', 'dispassionate', 'impartial'],
                'weight': 0.5,
                'intensifiers': []
            }
        }
    
    def _load_context_patterns(self):
        """Load contextual patterns for better emotion detection"""
        return {
            'question_patterns': [
                r'why\s+(am\s+i|do\s+i|can\s+i|should\s+i)',
                r'what\s+(is|was|will)\s+the\s+point',
                r'how\s+(can\s+i|do\s+i|will\s+i)',
                r'when\s+will\s+this\s+end'
            ],
            'exclamation_patterns': [
                r'!+',
                r'omg!+',
                r'wow!+',
                r'no\s+way!+'
            ],
            'crisis_patterns': [
                r'i\s+(want\s+to\s+)?die',
                r'i\s+(want\s+to\s+)?kill\s+myself',
                r'i\s+hate\s+my\s+life',
                r'nothing\s+matters',
                r'i\s+can\'t\s+go\s+on'
            ],
            'positive_patterns': [
                r'i\s+love\s+it',
                r'this\s+is\s+amazing',
                r'i\'m\s+so\s+happy',
                r'best\s+day\s+ever',
                r'i\s+feel\s+great'
            ]
        }
    
    def _load_transformer_models(self):
        """Load pre-trained transformer models for emotion detection"""
        try:
            # Emotion classification model
            self.transformer_models['emotion'] = pipeline(
                "text-classification",
                model="j-hartmann/emotion-english-distilroberta-base",
                return_all_scores=True
            )
            
            # Sentiment analysis model
            self.transformer_models['sentiment'] = pipeline(
                "sentiment-analysis",
                model="cardiffnlp/twitter-roberta-base-sentiment-latest",
                return_all_scores=True
            )
            
            print("✅ Transformer models loaded successfully")
            
        except Exception as e:
            print(f"⚠️  Error loading transformer models: {e}")
            self.transformer_models = {}
    
    def _initialize_ml_models(self):
        """Initialize machine learning models"""
        try:
            # TF-IDF vectorizer
            self.vectorizer = TfidfVectorizer(
                max_features=5000,
                stop_words='english',
                ngram_range=(1, 2),
                min_df=2,
                max_df=0.95
            )
            
            # Emotion classification model
            self.ml_models['emotion'] = LogisticRegression(
                multi_class='ovr',
                max_iter=1000,
                random_state=42
            )
            
            print("✅ ML models initialized successfully")
            
        except Exception as e:
            print(f"⚠️  Error initializing ML models: {e}")
            self.ml_models = {}
    
    def _load_pretrained_models(self):
        """Load pre-trained models from files"""
        try:
            # Try to load trained models
            model_path = "models/emotion_detector.pkl"
            if os.path.exists(model_path):
                with open(model_path, 'rb') as f:
                    self.ml_models = pickle.load(f)
                print("✅ Pre-trained models loaded")
        except Exception as e:
            print(f"⚠️  Could not load pre-trained models: {e}")
    
    def detect_emotion(self, text):
        """
        Detect emotion from text input using the specified model type
        Returns the most likely emotion
        """
        if not text or not text.strip():
            return 'neutral'
        
        text = text.lower().strip()
        
        if self.model_type == 'ensemble':
            return self._ensemble_detection(text)
        elif self.model_type == 'transformers' and self.transformer_models:
            return self._transformer_detection(text)
        elif self.model_type == 'ml' and self.ml_models:
            return self._ml_detection(text)
        elif self.model_type == 'hybrid':
            return self._hybrid_detection(text)
        else:
            return self._rule_based_detection(text)
    
    def _ensemble_detection(self, text):
        """Ensemble method combining multiple approaches"""
        scores = {}
        
        # Rule-based scores
        rule_scores = self._rule_based_detection(text, return_scores=True)
        
        # Transformer scores (if available)
        if self.transformer_models:
            transformer_scores = self._transformer_detection(text, return_scores=True)
            for emotion, score in transformer_scores.items():
                scores[emotion] = scores.get(emotion, 0) + score * 0.4
        
        # ML scores (if available)
        if self.ml_models:
            ml_scores = self._ml_detection(text, return_scores=True)
            for emotion, score in ml_scores.items():
                scores[emotion] = scores.get(emotion, 0) + score * 0.3
        
        # Rule-based scores
        for emotion, score in rule_scores.items():
            scores[emotion] = scores.get(emotion, 0) + score * 0.3
        
        return max(scores, key=scores.get) if scores else 'neutral'
    
    def _transformer_detection(self, text, return_scores=False):
        """Use transformer models for emotion detection"""
        if not self.transformer_models:
            return 'neutral'
        
        try:
            # Get emotion predictions
            emotion_results = self.transformer_models['emotion'](text)
            sentiment_results = self.transformer_models['sentiment'](text)
            
            # Process emotion results
            emotion_scores = {}
            for result in emotion_results[0]:
                emotion = result['label'].lower()
                score = result['score']
                emotion_scores[emotion] = score
            
            # Process sentiment results
            sentiment_scores = {}
            for result in sentiment_results[0]:
                sentiment = result['label'].lower()
                score = result['score']
                sentiment_scores[sentiment] = score
            
            # Map sentiment to emotions
            if 'positive' in sentiment_scores:
                emotion_scores['happy'] = emotion_scores.get('happy', 0) + sentiment_scores['positive'] * 0.3
            if 'negative' in sentiment_scores:
                emotion_scores['sad'] = emotion_scores.get('sad', 0) + sentiment_scores['negative'] * 0.3
            
            if return_scores:
                return emotion_scores
            
            return max(emotion_scores, key=emotion_scores.get) if emotion_scores else 'neutral'
            
        except Exception as e:
            print(f"Transformer detection error: {e}")
            return 'neutral'
    
    def _ml_detection(self, text, return_scores=False):
        """Use machine learning models for emotion detection"""
        if not self.ml_models or not self.vectorizer:
            return 'neutral'
        
        try:
            # Vectorize text
            text_vector = self.vectorizer.transform([text])
            
            # Get predictions
            if hasattr(self.ml_models['emotion'], 'predict_proba'):
                probabilities = self.ml_models['emotion'].predict_proba(text_vector)[0]
                classes = self.ml_models['emotion'].classes_
                
                emotion_scores = dict(zip(classes, probabilities))
                
                if return_scores:
                    return emotion_scores
                
                return classes[np.argmax(probabilities)]
            else:
                prediction = self.ml_models['emotion'].predict(text_vector)[0]
                return prediction
                
        except Exception as e:
            print(f"ML detection error: {e}")
            return 'neutral'
    
    def _hybrid_detection(self, text):
        """Hybrid approach combining multiple methods"""
        # Get scores from different methods
        rule_scores = self._rule_based_detection(text, return_scores=True)
        
        # Add contextual analysis
        context_scores = self._analyze_context(text)
        
        # Add linguistic features
        linguistic_scores = self._analyze_linguistic_features(text)
        
        # Combine scores with weights
        combined_scores = {}
        for emotion in rule_scores.keys():
            combined_scores[emotion] = (
                rule_scores[emotion] * 0.4 +
                context_scores.get(emotion, 0) * 0.3 +
                linguistic_scores.get(emotion, 0) * 0.3
            )
        
        return max(combined_scores, key=combined_scores.get) if combined_scores else 'neutral'
    
    def _rule_based_detection(self, text, return_scores=False):
        """Rule-based emotion detection using keywords and patterns"""
        # Get sentiment scores
        sentiment_scores = self.get_sentiment_scores(text)
        
        # Get keyword-based emotion scores
        keyword_scores = self.get_keyword_scores(text)
        
        # Get emoji-based emotion scores
        emoji_scores = self.get_emoji_scores(text)
        
        # Get contextual scores
        context_scores = self._analyze_context(text)
        
        # Combine all scores
        combined_scores = self.combine_scores(sentiment_scores, keyword_scores, emoji_scores, context_scores)
        
        if return_scores:
            return combined_scores
        
        return max(combined_scores, key=combined_scores.get) if combined_scores else 'neutral'
    
    def _analyze_context(self, text):
        """Analyze contextual patterns for emotion detection"""
        context_scores = {emotion: 0 for emotion in self.emotion_keywords.keys()}
        
        # Check for crisis patterns
        for pattern in self.context_patterns['crisis_patterns']:
            if re.search(pattern, text, re.IGNORECASE):
                context_scores['sad'] += 0.8
                context_scores['fear'] += 0.6
                break
        
        # Check for positive patterns
        for pattern in self.context_patterns['positive_patterns']:
            if re.search(pattern, text, re.IGNORECASE):
                context_scores['happy'] += 0.7
                break
        
        # Check for question patterns (often indicate confusion or anxiety)
        for pattern in self.context_patterns['question_patterns']:
            if re.search(pattern, text, re.IGNORECASE):
                context_scores['fear'] += 0.4
                context_scores['sad'] += 0.3
                break
        
        # Check for exclamation patterns (often indicate surprise or strong emotion)
        for pattern in self.context_patterns['exclamation_patterns']:
            if re.search(pattern, text, re.IGNORECASE):
                context_scores['surprise'] += 0.5
                context_scores['happy'] += 0.3
                break
        
        return context_scores
    
    def _analyze_linguistic_features(self, text):
        """Analyze linguistic features for emotion detection"""
        linguistic_scores = {emotion: 0 for emotion in self.emotion_keywords.keys()}
        
        if not self.nlp:
            return linguistic_scores
        
        try:
            doc = self.nlp(text)
            
            # Analyze sentence structure
            sentence_count = len(list(doc.sents))
            avg_sentence_length = len(doc) / max(sentence_count, 1)
            
            # Short sentences often indicate strong emotions
            if avg_sentence_length < 5:
                linguistic_scores['angry'] += 0.3
                linguistic_scores['fear'] += 0.2
            
            # Analyze punctuation
            exclamation_count = text.count('!')
            question_count = text.count('?')
            
            if exclamation_count > 2:
                linguistic_scores['angry'] += 0.4
                linguistic_scores['surprise'] += 0.3
            
            if question_count > 2:
                linguistic_scores['fear'] += 0.3
                linguistic_scores['sad'] += 0.2
            
            # Analyze word repetition (often indicates strong emotion)
            words = [token.text.lower() for token in doc if token.is_alpha]
            word_counts = {}
            for word in words:
                word_counts[word] = word_counts.get(word, 0) + 1
            
            repeated_words = [word for word, count in word_counts.items() if count > 1]
            if len(repeated_words) > 2:
                linguistic_scores['angry'] += 0.3
                linguistic_scores['fear'] += 0.2
            
            # Analyze capitalization (often indicates strong emotion)
            caps_ratio = sum(1 for c in text if c.isupper()) / max(len(text), 1)
            if caps_ratio > 0.3:
                linguistic_scores['angry'] += 0.5
                linguistic_scores['surprise'] += 0.3
            
        except Exception as e:
            print(f"Linguistic analysis error: {e}")
        
        return linguistic_scores
    
    def _detect_negation(self, text):
        """Detect negation in text and adjust emotion scores accordingly"""
        words = text.lower().split()
        negation_found = False
        
        for i, word in enumerate(words):
            if word in self.negation_words:
                # Check if negation affects emotion words
                for j in range(max(0, i-3), min(len(words), i+4)):
                    if j != i and words[j] in self._get_all_emotion_words():
                        negation_found = True
                        break
        
        return negation_found
    
    def _get_all_emotion_words(self):
        """Get all emotion words for negation detection"""
        all_words = set()
        for emotion_data in self.emotion_keywords.values():
            all_words.update(emotion_data['words'])
            all_words.update(emotion_data['intensifiers'])
        return all_words
    
    def _analyze_intensity(self, text):
        """Analyze emotional intensity from text"""
        words = text.lower().split()
        intensity_score = 1.0
        
        for word in words:
            if word in self.intensity_modifiers:
                intensity_score *= self.intensity_modifiers[word]
        
        # Check for repeated characters (e.g., "sooo", "nooo")
        repeated_chars = re.findall(r'(.)\1{2,}', text)
        if repeated_chars:
            intensity_score *= 1.5
        
        # Check for multiple exclamation marks
        exclamation_count = len(re.findall(r'!+', text))
        if exclamation_count > 1:
            intensity_score *= 1.2
        
        return min(intensity_score, 3.0)  # Cap at 3x intensity
    
    def get_sentiment_scores(self, text):
        """Get sentiment-based emotion scores using VADER and TextBlob"""
        # VADER sentiment analysis
        vader_scores = self.vader_analyzer.polarity_scores(text)
        
        # TextBlob sentiment analysis
        blob = TextBlob(text)
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity
        
        # Map sentiment to emotions with enhanced logic
        emotion_scores = {
            'happy': max(0, vader_scores['pos'] + max(0, polarity) * 0.5),
            'sad': max(0, vader_scores['neg'] + max(0, -polarity) * 0.5),
            'angry': max(0, vader_scores['neg'] * 0.8 + max(0, -polarity) * 0.3),
            'fear': max(0, vader_scores['neg'] * 0.6 + max(0, -polarity) * 0.2),
            'surprise': max(0, abs(vader_scores['compound']) * 0.5 + abs(polarity) * 0.3),
            'disgust': max(0, vader_scores['neg'] * 0.4 + max(0, -polarity) * 0.2),
            'neutral': max(0, (1 - abs(vader_scores['compound'])) * (1 - abs(polarity)) * 0.8)
        }
        
        # Adjust for subjectivity
        if subjectivity > 0.7:  # High subjectivity often indicates strong emotions
            for emotion in ['happy', 'sad', 'angry', 'fear']:
                emotion_scores[emotion] *= 1.2
        
        return emotion_scores
    
    def get_keyword_scores(self, text):
        """Get enhanced keyword-based emotion scores with intensity and negation handling"""
        scores = {emotion: 0 for emotion in self.emotion_keywords.keys()}
        
        words = re.findall(r'\b\w+\b', text.lower())
        
        # Check for negation
        negation_found = self._detect_negation(text)
        
        # Get intensity multiplier
        intensity_multiplier = self._analyze_intensity(text)
        
        for i, word in enumerate(words):
            for emotion, emotion_data in self.emotion_keywords.items():
                base_weight = emotion_data['weight']
                
                # Check regular emotion words
                if word in emotion_data['words']:
                    score = base_weight
                    
                    # Apply intensity multiplier
                    score *= intensity_multiplier
                    
                    # Handle negation
                    if negation_found:
                        # For negative emotions, negation might intensify
                        if emotion in ['sad', 'angry', 'fear', 'disgust']:
                            score *= 1.2
                        else:
                            score *= 0.3  # Reduce positive emotions with negation
                    
                    scores[emotion] += score
                
                # Check intensifier words
                elif word in emotion_data['intensifiers']:
                    score = base_weight * 1.5  # Intensifiers get higher weight
                    score *= intensity_multiplier
                    
                    if negation_found and emotion not in ['sad', 'angry', 'fear', 'disgust']:
                        score *= 0.3
                    
                    scores[emotion] += score
        
        # Normalize scores
        total_score = sum(scores.values())
        if total_score > 0:
            scores = {k: v/total_score for k, v in scores.items()}
        
        return scores
    
    def get_emoji_scores(self, text):
        """Get emoji-based emotion scores"""
        try:
            emoji_data = emot.emoticons(text)
            if not emoji_data:
                return {emotion: 0 for emotion in self.emotion_keywords.keys()}
            
            # Map emojis to emotions (simplified)
            emoji_emotion_map = {
                'happy': ['😊', '😄', '😃', '😁', '😆', '😍', '🥰', '😘', '😉', '🙂'],
                'sad': ['😢', '😭', '😔', '😞', '😟', '😕', '😿', '😾', '😿'],
                'angry': ['😠', '😡', '🤬', '😤', '😾', '👿', '💢'],
                'fear': ['😨', '😰', '😱', '😳', '😲', '😵', '🤯'],
                'surprise': ['😮', '😯', '😲', '😳', '🤯', '😱'],
                'disgust': ['🤢', '🤮', '😷', '🤧', '😵'],
                'neutral': ['😐', '😑', '😶', '🤐', '😴']
            }
            
            scores = {emotion: 0 for emotion in self.emotion_keywords.keys()}
            
            for emoji in emoji_data:
                for emotion, emoji_list in emoji_emotion_map.items():
                    if emoji in emoji_list:
                        scores[emotion] += 1
            
            # Normalize scores
            total_emojis = sum(scores.values())
            if total_emojis > 0:
                scores = {k: v/total_emojis for k, v in scores.items()}
            
            return scores
            
        except Exception as e:
            print(f"Emoji processing error: {e}")
            return {emotion: 0 for emotion in self.emotion_keywords.keys()}
    
    def combine_scores(self, sentiment_scores, keyword_scores, emoji_scores, context_scores=None):
        """Combine all emotion scores with adaptive weights"""
        combined = {}
        
        # Adaptive weights based on data availability
        weights = {
            'sentiment': 0.3,
            'keyword': 0.4,
            'emoji': 0.2,
            'context': 0.1
        }
        
        # Adjust weights if context scores are not available
        if context_scores is None:
            context_scores = {emotion: 0 for emotion in self.emotion_keywords.keys()}
            # Redistribute context weight to other methods
            weights['sentiment'] += weights['context'] * 0.5
            weights['keyword'] += weights['context'] * 0.5
            weights['context'] = 0
        
        for emotion in self.emotion_keywords.keys():
            combined[emotion] = (
                sentiment_scores.get(emotion, 0) * weights['sentiment'] +
                keyword_scores.get(emotion, 0) * weights['keyword'] +
                emoji_scores.get(emotion, 0) * weights['emoji'] +
                context_scores.get(emotion, 0) * weights['context']
            )
        
        return combined
    
    def get_emotion_intensity(self, text):
        """Get the intensity of the detected emotion"""
        emotion = self.detect_emotion(text)
        scores = self.combine_scores(
            self.get_sentiment_scores(text),
            self.get_keyword_scores(text),
            self.get_emoji_scores(text)
        )
        
        intensity = scores.get(emotion, 0)
        
        if intensity > 0.7:
            return "high"
        elif intensity > 0.4:
            return "medium"
        else:
            return "low"
    
    def get_emotion_confidence(self, text):
        """Get confidence score for emotion detection"""
        scores = self.combine_scores(
            self.get_sentiment_scores(text),
            self.get_keyword_scores(text),
            self.get_emoji_scores(text)
        )
        
        max_score = max(scores.values())
        return max_score
    
    def analyze_conversation_context(self, messages):
        """Analyze emotion trends in conversation history"""
        if not messages:
            return 'neutral'
        
        recent_messages = messages[-5:]  # Last 5 messages
        emotions = [self.detect_emotion(msg) for msg in recent_messages]
        
        # Count emotion frequencies
        emotion_counts = {}
        for emotion in emotions:
            emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
        
        # Return most frequent emotion
        return max(emotion_counts, key=emotion_counts.get)
    
    def get_emotional_insights(self, text):
        """Get detailed emotional insights from text"""
        emotion = self.detect_emotion(text)
        intensity = self.get_emotion_intensity(text)
        confidence = self.get_emotion_confidence(text)
        
        insights = {
            'primary_emotion': emotion,
            'intensity': intensity,
            'confidence': confidence,
            'sentiment_polarity': self.vader_analyzer.polarity_scores(text)['compound'],
            'recommendations': self.get_emotion_recommendations(emotion, intensity)
        }
        
        return insights
    
    def get_emotion_recommendations(self, emotion, intensity):
        """Get recommendations based on detected emotion"""
        recommendations = {
            'happy': {
                'low': ['Keep up the positive energy!', 'Share your happiness with others'],
                'medium': ['This is great! Consider journaling about what made you happy'],
                'high': ['Wonderful! Your positive energy is contagious']
            },
            'sad': {
                'low': ['It\'s okay to feel down sometimes', 'Try some gentle self-care'],
                'medium': ['Consider talking to someone you trust', 'Try some relaxation exercises'],
                'high': ['Please reach out for support', 'Consider professional help if this persists']
            },
            'angry': {
                'low': ['Take a few deep breaths', 'Try to identify what\'s causing the anger'],
                'medium': ['Step away from the situation if possible', 'Try some physical exercise'],
                'high': ['Take a break and cool down', 'Consider talking to someone about your feelings']
            },
            'fear': {
                'low': ['Breathe deeply and remind yourself you\'re safe', 'Try grounding techniques'],
                'medium': ['Focus on what you can control', 'Consider talking to someone about your fears'],
                'high': ['Please reach out for support', 'Consider professional help for anxiety']
            },
            'neutral': {
                'low': ['You seem calm and balanced', 'Consider what might bring you joy'],
                'medium': ['A neutral mood is perfectly normal', 'Try some light activities you enjoy'],
                'high': ['You seem very balanced today', 'Consider exploring new interests']
            }
        }
        
        return recommendations.get(emotion, {}).get(intensity, ['Take care of yourself'])
    
    def train_ml_model(self, training_data, test_size=0.2):
        """Train machine learning model on provided data"""
        if not SKLEARN_AVAILABLE or not self.vectorizer:
            print("ML training not available. Install scikit-learn and initialize models.")
            return False
        
        try:
            # Prepare data
            texts = [item['text'] for item in training_data]
            labels = [item['emotion'] for item in training_data]
            
            # Vectorize texts
            X = self.vectorizer.fit_transform(texts)
            y = labels
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=42, stratify=y
            )
            
            # Train model
            self.ml_models['emotion'].fit(X_train, y_train)
            
            # Evaluate model
            y_pred = self.ml_models['emotion'].predict(X_test)
            accuracy = (y_pred == y_test).mean()
            
            print(f"Model trained successfully. Accuracy: {accuracy:.3f}")
            print("\nClassification Report:")
            print(classification_report(y_test, y_pred))
            
            # Save model
            self._save_model()
            
            return True
            
        except Exception as e:
            print(f"Training error: {e}")
            return False
    
    def _save_model(self):
        """Save trained model to file"""
        try:
            os.makedirs("models", exist_ok=True)
            model_data = {
                'vectorizer': self.vectorizer,
                'ml_models': self.ml_models
            }
            
            with open("models/emotion_detector.pkl", 'wb') as f:
                pickle.dump(model_data, f)
            
            print("Model saved successfully")
            
        except Exception as e:
            print(f"Error saving model: {e}")
    
    def evaluate_model(self, test_data):
        """Evaluate model performance on test data"""
        if not self.ml_models or not self.vectorizer:
            print("No trained model available for evaluation")
            return None
        
        try:
            texts = [item['text'] for item in test_data]
            true_labels = [item['emotion'] for item in test_data]
            
            # Vectorize texts
            X = self.vectorizer.transform(texts)
            
            # Get predictions
            predictions = self.ml_models['emotion'].predict(X)
            
            # Calculate accuracy
            accuracy = (predictions == true_labels).mean()
            
            # Get detailed report
            report = classification_report(true_labels, predictions, output_dict=True)
            
            return {
                'accuracy': accuracy,
                'classification_report': report,
                'predictions': list(predictions),
                'true_labels': true_labels
            }
            
        except Exception as e:
            print(f"Evaluation error: {e}")
            return None
    
    def get_emotion_probabilities(self, text):
        """Get probability distribution for all emotions"""
        if self.model_type == 'ml' and self.ml_models and self.vectorizer:
            try:
                text_vector = self.vectorizer.transform([text])
                if hasattr(self.ml_models['emotion'], 'predict_proba'):
                    probabilities = self.ml_models['emotion'].predict_proba(text_vector)[0]
                    classes = self.ml_models['emotion'].classes_
                    return dict(zip(classes, probabilities))
            except Exception as e:
                print(f"Probability calculation error: {e}")
        
        # Fallback to rule-based probabilities
        sentiment_scores = self.get_sentiment_scores(text)
        keyword_scores = self.get_keyword_scores(text)
        emoji_scores = self.get_emoji_scores(text)
        context_scores = self._analyze_context(text)
        
        combined_scores = self.combine_scores(sentiment_scores, keyword_scores, emoji_scores, context_scores)
        
        # Normalize to probabilities
        total_score = sum(combined_scores.values())
        if total_score > 0:
            return {emotion: score/total_score for emotion, score in combined_scores.items()}
        
        return {emotion: 1.0/len(combined_scores) for emotion in combined_scores.keys()}
    
    def batch_detect_emotions(self, texts):
        """Detect emotions for multiple texts efficiently"""
        results = []
        
        for text in texts:
            result = {
                'text': text,
                'emotion': self.detect_emotion(text),
                'intensity': self.get_emotion_intensity(text),
                'confidence': self.get_emotion_confidence(text),
                'probabilities': self.get_emotion_probabilities(text)
            }
            results.append(result)
        
        return results
    
    def get_emotion_statistics(self, texts):
        """Get emotion statistics from a collection of texts"""
        emotions = [self.detect_emotion(text) for text in texts]
        
        emotion_counts = {}
        for emotion in emotions:
            emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
        
        total_texts = len(texts)
        emotion_percentages = {
            emotion: (count / total_texts) * 100 
            for emotion, count in emotion_counts.items()
        }
        
        return {
            'total_texts': total_texts,
            'emotion_counts': emotion_counts,
            'emotion_percentages': emotion_percentages,
            'most_common_emotion': max(emotion_counts, key=emotion_counts.get),
            'emotion_diversity': len(emotion_counts) / len(self.emotion_keywords)
        }
    
    def create_emotion_dataset(self, texts_with_emotions, save_path="emotion_dataset.json"):
        """Create a dataset for training from texts with known emotions"""
        dataset = []
        
        for item in texts_with_emotions:
            if isinstance(item, dict) and 'text' in item and 'emotion' in item:
                dataset.append({
                    'text': item['text'],
                    'emotion': item['emotion'],
                    'intensity': item.get('intensity', 'medium'),
                    'confidence': item.get('confidence', 0.5)
                })
            elif isinstance(item, str):
                # Auto-detect emotion for single text
                emotion = self.detect_emotion(item)
                dataset.append({
                    'text': item,
                    'emotion': emotion,
                    'intensity': self.get_emotion_intensity(item),
                    'confidence': self.get_emotion_confidence(item)
                })
        
        try:
            with open(save_path, 'w') as f:
                json.dump(dataset, f, indent=2)
            print(f"Dataset saved to {save_path}")
            return True
        except Exception as e:
            print(f"Error saving dataset: {e}")
            return False
    
    def load_emotion_dataset(self, dataset_path):
        """Load emotion dataset from file"""
        try:
            with open(dataset_path, 'r') as f:
                dataset = json.load(f)
            return dataset
        except Exception as e:
            print(f"Error loading dataset: {e}")
            return []
    
    def compare_models(self, test_data):
        """Compare performance of different model types"""
        results = {}
        
        # Test rule-based
        original_type = self.model_type
        self.model_type = 'rule_based'
        rule_predictions = [self.detect_emotion(item['text']) for item in test_data]
        results['rule_based'] = {
            'predictions': rule_predictions,
            'accuracy': sum(1 for i, pred in enumerate(rule_predictions) 
                          if pred == test_data[i]['emotion']) / len(test_data)
        }
        
        # Test ensemble if available
        if self.transformer_models or self.ml_models:
            self.model_type = 'ensemble'
            ensemble_predictions = [self.detect_emotion(item['text']) for item in test_data]
            results['ensemble'] = {
                'predictions': ensemble_predictions,
                'accuracy': sum(1 for i, pred in enumerate(ensemble_predictions) 
                              if pred == test_data[i]['emotion']) / len(test_data)
            }
        
        # Restore original type
        self.model_type = original_type
        
        return results
    
    def get_model_info(self):
        """Get information about the current model configuration"""
        info = {
            'model_type': self.model_type,
            'available_methods': [],
            'transformer_models': list(self.transformer_models.keys()) if self.transformer_models else [],
            'ml_models': list(self.ml_models.keys()) if self.ml_models else [],
            'spacy_available': self.nlp is not None,
            'emotion_categories': list(self.emotion_keywords.keys())
        }
        
        if self.transformer_models:
            info['available_methods'].append('transformers')
        if self.ml_models:
            info['available_methods'].append('ml')
        if self.nlp:
            info['available_methods'].append('linguistic_analysis')
        
        info['available_methods'].extend(['rule_based', 'sentiment', 'keyword', 'emoji', 'context'])
        
        return info
