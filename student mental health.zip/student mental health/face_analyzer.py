"""
Face Analysis Module
Handles face detection, recognition, and facial emotion analysis
"""

import cv2
import numpy as np
import mediapipe as mp
import dlib
from scipy.spatial import distance
import json
import os

class FaceAnalyzer:
    def __init__(self):
        # Initialize MediaPipe face detection
        self.mp_face_detection = mp.solutions.face_detection
        self.mp_drawing = mp.solutions.drawing_utils
        self.face_detection = self.mp_face_detection.FaceDetection(min_detection_confidence=0.5)
        
        # Initialize MediaPipe face mesh for detailed analysis
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        
        # Initialize dlib for facial landmark detection
        self.detector = dlib.get_frontal_face_detector()
        self.predictor = None
        
        # Load dlib shape predictor if available
        try:
            self.predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
        except:
            print("Dlib shape predictor not found. Using MediaPipe only.")
        
        # Emotion detection model (simplified)
        self.emotion_model = self.load_emotion_model()
        
        # Face recognition database
        self.known_faces = {}
        self.face_encodings = {}
        
        # Current emotion state
        self.current_emotion = "neutral"
        self.emotion_history = []
        
        # Stress indicators
        self.stress_indicators = {
            'eye_squint': 0,
            'brow_furrow': 0,
            'lip_tension': 0,
            'jaw_clench': 0
        }
    
    def load_emotion_model(self):
        """Load emotion detection model (simplified version)"""
        # In a real implementation, you would load a pre-trained model
        # For now, we'll use rule-based detection
        return None
    
    def process_frame(self, frame):
        """Process a single frame for face detection and emotion analysis"""
        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Detect faces using MediaPipe
        results = self.face_detection.process(rgb_frame)
        
        if results.detections:
            for detection in results.detections:
                # Get bounding box
                bbox = detection.location_data.relative_bounding_box
                h, w, c = frame.shape
                
                x = int(bbox.xmin * w)
                y = int(bbox.ymin * h)
                width = int(bbox.width * w)
                height = int(bbox.height * h)
                
                # Draw bounding box
                cv2.rectangle(frame, (x, y), (x + width, y + height), (0, 255, 0), 2)
                
                # Extract face region
                face_region = frame[y:y+height, x:x+width]
                
                if face_region.size > 0:
                    # Analyze emotion
                    emotion = self.analyze_emotion(face_region)
                    self.current_emotion = emotion
                    
                    # Draw emotion label
                    cv2.putText(frame, f"Emotion: {emotion}", (x, y-10), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                    
                    # Analyze stress indicators
                    stress_level = self.analyze_stress_indicators(face_region)
                    
                    # Draw stress level
                    cv2.putText(frame, f"Stress: {stress_level}", (x, y+height+20), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        return frame
    
    def analyze_emotion(self, face_region):
        """Analyze emotion from face region"""
        try:
            # Convert to grayscale for analysis
            gray_face = cv2.cvtColor(face_region, cv2.COLOR_BGR2GRAY)
            
            # Resize for consistent analysis
            gray_face = cv2.resize(gray_face, (48, 48))
            
            # Use MediaPipe face mesh for detailed analysis
            rgb_face = cv2.cvtColor(face_region, cv2.COLOR_BGR2RGB)
            mesh_results = self.face_mesh.process(rgb_face)
            
            if mesh_results.multi_face_landmarks:
                landmarks = mesh_results.multi_face_landmarks[0]
                emotion = self.analyze_facial_landmarks(landmarks)
                return emotion
            
            # Fallback to simple analysis
            return self.simple_emotion_analysis(gray_face)
            
        except Exception as e:
            print(f"Emotion analysis error: {e}")
            return "neutral"
    
    def analyze_facial_landmarks(self, landmarks):
        """Analyze facial landmarks for emotion detection"""
        # Key landmark indices for emotion analysis
        LANDMARKS = {
            'left_eye': [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246],
            'right_eye': [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398],
            'left_eyebrow': [46, 53, 52, 65, 55],
            'right_eyebrow': [276, 283, 282, 295, 285],
            'nose': [1, 2, 5, 4, 6, 19, 20, 94, 125, 141, 235, 236, 3, 51, 48, 115, 131, 134, 102, 49, 220, 305, 281, 360, 279],
            'mouth': [61, 84, 17, 314, 405, 320, 307, 375, 321, 308, 324, 318, 13, 82, 81, 80, 78, 95, 88, 178, 87, 14, 317, 402, 318, 324, 308, 415],
            'jaw': [0, 11, 12, 13, 14, 15, 16, 17, 18, 200, 199, 175, 176, 148, 152, 377, 400, 378, 379, 365, 397, 288, 361, 323, 454, 356, 389, 251, 284, 332, 297, 338, 10, 151, 9, 8, 107, 55, 65, 52, 53, 46]
        }
        
        # Calculate facial action units (simplified)
        action_units = self.calculate_action_units(landmarks, LANDMARKS)
        
        # Map action units to emotions
        emotion = self.map_action_units_to_emotion(action_units)
        
        return emotion
    
    def calculate_action_units(self, landmarks, landmark_groups):
        """Calculate facial action units from landmarks"""
        action_units = {}
        
        # Eye openness
        left_eye_points = [landmarks.landmark[i] for i in landmark_groups['left_eye']]
        right_eye_points = [landmarks.landmark[i] for i in landmark_groups['right_eye']]
        
        left_eye_openness = self.calculate_eye_openness(left_eye_points)
        right_eye_openness = self.calculate_eye_openness(right_eye_points)
        action_units['eye_openness'] = (left_eye_openness + right_eye_openness) / 2
        
        # Eyebrow raise
        left_brow_points = [landmarks.landmark[i] for i in landmark_groups['left_eyebrow']]
        right_brow_points = [landmarks.landmark[i] for i in landmark_groups['right_eyebrow']]
        
        left_brow_raise = self.calculate_brow_raise(left_brow_points)
        right_brow_raise = self.calculate_brow_raise(right_brow_points)
        action_units['brow_raise'] = (left_brow_raise + right_brow_raise) / 2
        
        # Mouth openness
        mouth_points = [landmarks.landmark[i] for i in landmark_groups['mouth']]
        action_units['mouth_openness'] = self.calculate_mouth_openness(mouth_points)
        
        # Mouth corners
        action_units['mouth_corners'] = self.calculate_mouth_corners(mouth_points)
        
        return action_units
    
    def calculate_eye_openness(self, eye_points):
        """Calculate eye openness from eye landmark points"""
        if len(eye_points) < 4:
            return 0.5
        
        # Use vertical distance between upper and lower eyelid
        upper_lid = eye_points[1].y
        lower_lid = eye_points[5].y
        openness = abs(upper_lid - lower_lid)
        
        return min(1.0, max(0.0, openness * 10))
    
    def calculate_brow_raise(self, brow_points):
        """Calculate eyebrow raise from brow landmark points"""
        if len(brow_points) < 3:
            return 0.0
        
        # Use vertical position of brow points
        brow_y = sum(point.y for point in brow_points) / len(brow_points)
        return max(0.0, min(1.0, (0.3 - brow_y) * 5))
    
    def calculate_mouth_openness(self, mouth_points):
        """Calculate mouth openness from mouth landmark points"""
        if len(mouth_points) < 4:
            return 0.0
        
        # Use vertical distance between upper and lower lip
        upper_lip = mouth_points[3].y
        lower_lip = mouth_points[9].y
        openness = abs(upper_lip - lower_lip)
        
        return min(1.0, max(0.0, openness * 10))
    
    def calculate_mouth_corners(self, mouth_points):
        """Calculate mouth corner positions"""
        if len(mouth_points) < 2:
            return 0.0
        
        # Use horizontal position of mouth corners
        left_corner = mouth_points[0].x
        right_corner = mouth_points[6].x
        corner_angle = (right_corner - left_corner) * 2
        
        return max(-1.0, min(1.0, corner_angle))
    
    def map_action_units_to_emotion(self, action_units):
        """Map facial action units to emotions"""
        eye_openness = action_units.get('eye_openness', 0.5)
        brow_raise = action_units.get('brow_raise', 0.0)
        mouth_openness = action_units.get('mouth_openness', 0.0)
        mouth_corners = action_units.get('mouth_corners', 0.0)
        
        # Rule-based emotion detection
        if mouth_corners > 0.3 and eye_openness > 0.4:
            return "happy"
        elif mouth_corners < -0.3 and brow_raise < 0.1:
            return "sad"
        elif brow_raise > 0.3 and eye_openness > 0.6:
            return "surprise"
        elif brow_raise < -0.2 and mouth_corners < -0.1:
            return "angry"
        elif eye_openness < 0.3 and brow_raise > 0.1:
            return "fear"
        elif mouth_openness > 0.3:
            return "disgust"
        else:
            return "neutral"
    
    def simple_emotion_analysis(self, gray_face):
        """Simple emotion analysis using basic image features"""
        # Calculate basic features
        brightness = np.mean(gray_face)
        contrast = np.std(gray_face)
        
        # Simple rule-based classification
        if brightness > 120 and contrast > 30:
            return "happy"
        elif brightness < 80 and contrast < 20:
            return "sad"
        elif contrast > 40:
            return "surprise"
        else:
            return "neutral"
    
    def analyze_stress_indicators(self, face_region):
        """Analyze stress indicators from facial features"""
        try:
            # Convert to grayscale
            gray_face = cv2.cvtColor(face_region, cv2.COLOR_BGR2GRAY)
            
            # Use MediaPipe face mesh
            rgb_face = cv2.cvtColor(face_region, cv2.COLOR_BGR2RGB)
            mesh_results = self.face_mesh.process(rgb_face)
            
            if mesh_results.multi_face_landmarks:
                landmarks = mesh_results.multi_face_landmarks[0]
                stress_level = self.calculate_stress_level(landmarks)
                return stress_level
            
            return "low"
            
        except Exception as e:
            print(f"Stress analysis error: {e}")
            return "low"
    
    def calculate_stress_level(self, landmarks):
        """Calculate stress level from facial landmarks"""
        # Key stress indicators
        stress_score = 0
        
        # Eye squinting (stress indicator)
        eye_squint = self.calculate_eye_squint(landmarks)
        stress_score += eye_squint * 0.3
        
        # Brow furrowing (stress indicator)
        brow_furrow = self.calculate_brow_furrow(landmarks)
        stress_score += brow_furrow * 0.3
        
        # Lip tension (stress indicator)
        lip_tension = self.calculate_lip_tension(landmarks)
        stress_score += lip_tension * 0.2
        
        # Jaw clenching (stress indicator)
        jaw_clench = self.calculate_jaw_clench(landmarks)
        stress_score += jaw_clench * 0.2
        
        # Map stress score to level
        if stress_score > 0.7:
            return "high"
        elif stress_score > 0.4:
            return "medium"
        else:
            return "low"
    
    def calculate_eye_squint(self, landmarks):
        """Calculate eye squinting level"""
        # Simplified calculation
        return 0.0  # Placeholder
    
    def calculate_brow_furrow(self, landmarks):
        """Calculate brow furrowing level"""
        # Simplified calculation
        return 0.0  # Placeholder
    
    def calculate_lip_tension(self, landmarks):
        """Calculate lip tension level"""
        # Simplified calculation
        return 0.0  # Placeholder
    
    def calculate_jaw_clench(self, landmarks):
        """Calculate jaw clenching level"""
        # Simplified calculation
        return 0.0  # Placeholder
    
    def get_current_emotion(self):
        """Get current detected emotion"""
        return self.current_emotion
    
    def get_emotion_history(self):
        """Get emotion history"""
        return self.emotion_history
    
    def add_face_to_database(self, name, face_encoding):
        """Add a face to the recognition database"""
        self.known_faces[name] = face_encoding
        self.save_face_database()
    
    def recognize_face(self, face_encoding):
        """Recognize a face from encoding"""
        if not self.known_faces:
            return None
        
        # Simple distance-based recognition
        min_distance = float('inf')
        recognized_name = None
        
        for name, known_encoding in self.known_faces.items():
            distance = np.linalg.norm(face_encoding - known_encoding)
            if distance < min_distance:
                min_distance = distance
                recognized_name = name
        
        # Threshold for recognition
        if min_distance < 0.6:
            return recognized_name
        
        return None
    
    def save_face_database(self):
        """Save face database to file"""
        try:
            with open('face_database.json', 'w') as f:
                # Convert numpy arrays to lists for JSON serialization
                serializable_faces = {}
                for name, encoding in self.known_faces.items():
                    serializable_faces[name] = encoding.tolist()
                json.dump(serializable_faces, f)
        except Exception as e:
            print(f"Error saving face database: {e}")
    
    def load_face_database(self):
        """Load face database from file"""
        try:
            if os.path.exists('face_database.json'):
                with open('face_database.json', 'r') as f:
                    serializable_faces = json.load(f)
                    self.known_faces = {}
                    for name, encoding_list in serializable_faces.items():
                        self.known_faces[name] = np.array(encoding_list)
        except Exception as e:
            print(f"Error loading face database: {e}")
    
    def cleanup(self):
        """Cleanup resources"""
        if hasattr(self, 'face_detection'):
            self.face_detection.close()
        if hasattr(self, 'face_mesh'):
            self.face_mesh.close()
