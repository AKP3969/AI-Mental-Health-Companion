#!/usr/bin/env python3
"""
Simple Emotion Detection Test
Tests basic functionality without requiring all dependencies
"""

import sys
import os

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_basic_functionality():
    """Test basic emotion detection without external dependencies"""
    print("🧠 Testing Basic Emotion Detection (No Dependencies)")
    print("=" * 60)
    
    # Simple rule-based emotion detection
    emotion_keywords = {
        'happy': ['happy', 'joy', 'excited', 'cheerful', 'delighted', 'pleased', 'content', 'satisfied'],
        'sad': ['sad', 'depressed', 'down', 'blue', 'melancholy', 'gloomy', 'unhappy', 'miserable'],
        'angry': ['angry', 'mad', 'furious', 'irritated', 'annoyed', 'rage', 'frustrated', 'livid'],
        'fear': ['afraid', 'scared', 'fearful', 'terrified', 'anxious', 'worried', 'nervous', 'panic'],
        'surprise': ['surprised', 'shocked', 'amazed', 'astonished', 'startled', 'bewildered'],
        'disgust': ['disgusted', 'revolted', 'sickened', 'repulsed', 'nauseated', 'appalled'],
        'neutral': ['okay', 'fine', 'normal', 'alright', 'so-so', 'meh', 'whatever']
    }
    
    def simple_emotion_detection(text):
        """Simple emotion detection using keyword matching"""
        text = text.lower()
        emotion_scores = {emotion: 0 for emotion in emotion_keywords.keys()}
        
        words = text.split()
        for word in words:
            for emotion, keywords in emotion_keywords.items():
                if word in keywords:
                    emotion_scores[emotion] += 1
        
        # Return emotion with highest score
        if sum(emotion_scores.values()) == 0:
            return 'neutral'
        
        return max(emotion_scores, key=emotion_scores.get)
    
    # Test cases
    test_cases = [
        "I'm so happy today! This is amazing!",
        "I feel really sad and depressed about everything",
        "I'm absolutely furious about what happened",
        "I'm scared and anxious about the future",
        "Wow! I'm so surprised by this news!",
        "I'm disgusted by this behavior",
        "I feel okay, nothing special",
        "I'm extremely excited about the trip!",
        "I can't believe this is happening to me",
        "I love this new job!"
    ]
    
    print("Testing emotion detection:")
    print()
    
    for i, text in enumerate(test_cases, 1):
        emotion = simple_emotion_detection(text)
        print(f"{i:2d}. Text: '{text}'")
        print(f"    Detected emotion: {emotion}")
        print()
    
    print("✅ Basic emotion detection test completed!")
    print()
    print("To test the full advanced system:")
    print("1. Install dependencies: pip install -r requirements.txt")
    print("2. Run: python test_emotion_detection.py")
    print("3. Or run the main application: python main.py")

def test_crisis_detection():
    """Test crisis detection patterns"""
    print("🚨 Testing Crisis Detection Patterns")
    print("=" * 60)
    
    crisis_patterns = [
        r'i\s+(want\s+to\s+)?die',
        r'i\s+(want\s+to\s+)?kill\s+myself',
        r'i\s+hate\s+my\s+life',
        r'nothing\s+matters',
        r'i\s+can\'t\s+go\s+on'
    ]
    
    import re
    
    def detect_crisis(text):
        """Detect crisis indicators in text"""
        text = text.lower()
        for pattern in crisis_patterns:
            if re.search(pattern, text):
                return True
        return False
    
    test_texts = [
        "I want to die",
        "I want to kill myself",
        "I hate my life",
        "Nothing matters anymore",
        "I can't go on like this",
        "I'm feeling sad today",
        "I'm angry about work",
        "I'm worried about the future",
        "I'm having a bad day",
        "I love this new job!"
    ]
    
    print("Testing crisis detection:")
    print()
    
    for text in test_texts:
        is_crisis = detect_crisis(text)
        status = "🚨 CRISIS" if is_crisis else "✅ Normal"
        print(f"'{text}' -> {status}")
    
    print()
    print("✅ Crisis detection test completed!")

def test_intensity_analysis():
    """Test emotional intensity analysis"""
    print("📊 Testing Emotional Intensity Analysis")
    print("=" * 60)
    
    intensity_modifiers = {
        'very': 1.5, 'extremely': 2.0, 'super': 1.8, 'really': 1.3,
        'quite': 1.2, 'somewhat': 0.8, 'slightly': 0.6, 'a bit': 0.7,
        'totally': 1.6, 'completely': 1.7, 'absolutely': 1.8
    }
    
    def analyze_intensity(text):
        """Analyze emotional intensity from text"""
        words = text.lower().split()
        intensity_score = 1.0
        
        for word in words:
            if word in intensity_modifiers:
                intensity_score *= intensity_modifiers[word]
        
        # Check for repeated characters (e.g., "sooo", "nooo")
        import re
        repeated_chars = re.findall(r'(.)\1{2,}', text)
        if repeated_chars:
            intensity_score *= 1.5
        
        # Check for multiple exclamation marks
        exclamation_count = len(re.findall(r'!+', text))
        if exclamation_count > 1:
            intensity_score *= 1.2
        
        return min(intensity_score, 3.0)  # Cap at 3x intensity
    
    test_texts = [
        "I'm happy",
        "I'm very happy",
        "I'm extremely happy",
        "I'm soooooo happy!!!",
        "I'm not very happy",
        "I'm somewhat sad",
        "I'm absolutely furious!!!",
        "I'm a bit worried",
        "I'm totally excited!",
        "I'm completely devastated"
    ]
    
    print("Testing intensity analysis:")
    print()
    
    for text in test_texts:
        intensity = analyze_intensity(text)
        level = "Low" if intensity < 1.2 else "Medium" if intensity < 1.8 else "High"
        print(f"'{text}' -> Intensity: {intensity:.2f} ({level})")
    
    print()
    print("✅ Intensity analysis test completed!")

def main():
    """Run all simple tests"""
    print("🚀 Simple Emotion Detection Test Suite")
    print("=" * 60)
    print("Testing basic functionality without external dependencies")
    print()
    
    try:
        test_basic_functionality()
        print()
        test_crisis_detection()
        print()
        test_intensity_analysis()
        print()
        
        print("=" * 60)
        print("✅ All simple tests completed successfully!")
        print()
        print("📚 Next Steps:")
        print("1. Install dependencies: pip install -r requirements.txt")
        print("2. Run advanced tests: python test_emotion_detection.py")
        print("3. Run the main application: python main.py")
        print("4. Read the documentation: EMOTION_DETECTION_GUIDE.md")
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
