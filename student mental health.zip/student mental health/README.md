# AI Mental Health Companion

A comprehensive AI-powered mental health support system that provides emotional analysis, relaxation exercises, and real-time counselor connection for students and individuals seeking mental health support.

## 🌟 Features

### Core Functionality
- **Multi-modal Emotion Detection**: Analyzes emotions from text, facial expressions, and voice
- **Intelligent Chatbot**: Provides empathetic responses and mental health support
- **Real-time Face Analysis**: Detects facial emotions and stress indicators using computer vision
- **Speech Processing**: Voice-to-text conversion with emotion analysis
- **Relaxation Exercises**: Guided breathing, meditation, and progressive muscle relaxation
- **Journaling System**: Digital journal with prompts and mood tracking
- **Counselor Connection**: Real-time connection to mental health professionals
- **Progress Tracking**: Comprehensive analytics and data visualization

### Advanced Features
- **Crisis Detection**: Automatically detects crisis situations and provides emergency resources
- **Personalized Responses**: Adapts responses based on user's emotional state and history
- **Data Analytics**: Tracks mood trends, emotion patterns, and progress over time
- **Multi-language Support**: Emotion detection in multiple languages
- **Privacy-Focused**: Local data storage with optional cloud backup

## 🚀 Installation

### Prerequisites
- Python 3.8 or higher
- Webcam for face analysis
- Microphone for speech processing
- 4GB RAM minimum (8GB recommended)

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd "student mental health"
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Download additional models** (optional)
   ```bash
   # Download dlib shape predictor for enhanced face analysis
   wget http://dlib.net/files/shape_predictor_68_face_landmarks.dat
   ```

4. **Run the application**
   ```bash
   python main.py
   ```

## 📱 Usage

### Getting Started
1. Launch the application using `python main.py`
2. Allow camera and microphone permissions when prompted
3. Start with the camera to enable face emotion detection
4. Use the chat interface to interact with the AI companion
5. Explore relaxation exercises and journaling features

### Interface Overview

#### Main Tabs
- **Chat**: Primary interaction with the AI companion
- **Relaxation**: Breathing exercises, music, and meditation
- **Counselor**: Real-time connection to mental health professionals
- **Progress**: Analytics and mood tracking visualization

#### Camera Panel
- Real-time face emotion detection
- Stress level monitoring
- Visual feedback for relaxation exercises

### Key Features Usage

#### Emotion Detection
- **Text**: Type messages to get emotion analysis
- **Face**: Enable camera for real-time facial emotion detection
- **Voice**: Use microphone for voice emotion analysis

#### Relaxation Exercises
- **Breathing**: Choose from multiple breathing patterns
- **Music**: Play relaxing background music
- **Journaling**: Write with guided prompts

#### Crisis Support
- Automatic detection of crisis keywords
- Immediate access to emergency resources
- Connection to crisis counselors

## 🔧 Configuration

### Environment Variables
Create a `.env` file for configuration:
```env
# Database settings
DATABASE_PATH=mental_health_data.db

# API keys (if using external services)
OPENAI_API_KEY=your_openai_key
GOOGLE_SPEECH_API_KEY=your_google_key

# Counselor service settings
COUNSELOR_SERVICE_URL=your_counselor_service_url
COUNSELOR_API_KEY=your_counselor_api_key
```

### Customization
- Modify `emotion_detector.py` to adjust emotion detection sensitivity
- Update `chatbot.py` to customize response patterns
- Edit `relaxation_exercises.py` to add new exercises
- Configure `data_manager.py` for different data storage options

## 📊 Data & Privacy

### Data Storage
- All data is stored locally by default
- SQLite database for structured data
- JSON files for conversation history
- Optional cloud backup available

### Privacy Features
- No data sent to external servers without consent
- Local processing for emotion detection
- Encrypted data storage options
- User control over data retention

### Data Export
- Export all data to JSON format
- Generate progress reports
- Create mood and emotion charts
- Backup and restore functionality

## 🛠️ Technical Architecture

### Core Modules
- `main.py`: Main application and GUI
- `emotion_detector.py`: Text-based emotion analysis
- `face_analyzer.py`: Facial emotion detection
- `speech_processor.py`: Voice processing and analysis
- `chatbot.py`: Conversational AI responses
- `relaxation_exercises.py`: Relaxation techniques
- `counselor_connection.py`: Counselor communication
- `data_manager.py`: Data storage and analytics

### Dependencies
- **Computer Vision**: OpenCV, MediaPipe, dlib
- **Machine Learning**: TensorFlow, scikit-learn
- **NLP**: Transformers, TextBlob, VADER
- **Audio Processing**: librosa, speech_recognition
- **GUI**: tkinter, matplotlib
- **Database**: SQLite, pandas

## 🔍 Troubleshooting

### Common Issues

#### Camera Not Working
- Ensure camera permissions are granted
- Check if camera is being used by another application
- Try restarting the application

#### Microphone Issues
- Verify microphone permissions
- Check audio device settings
- Ensure PyAudio is properly installed

#### Performance Issues
- Close other applications to free up memory
- Reduce camera resolution in settings
- Disable unnecessary features

#### Installation Problems
- Update pip: `pip install --upgrade pip`
- Install dependencies one by one
- Check Python version compatibility

### Error Messages
- **"Camera not found"**: Check camera connection and permissions
- **"Microphone error"**: Verify audio device and permissions
- **"Database error"**: Check file permissions and disk space
- **"Model loading error"**: Ensure all dependencies are installed

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

### Code Style
- Follow PEP 8 guidelines
- Add docstrings to functions
- Include type hints where possible
- Write comprehensive tests

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## ⚠️ Disclaimer

This application is designed to provide mental health support and should not replace professional medical advice. If you're experiencing a mental health crisis, please contact emergency services or a qualified mental health professional immediately.

## 📞 Emergency Resources

- **Crisis Text Line**: Text HOME to 741741
- **Suicide & Crisis Lifeline**: Call 988
- **Emergency Services**: Call 911
- **International Association for Suicide Prevention**: https://www.iasp.info/resources/Crisis_Centres/

## 🙏 Acknowledgments

- OpenCV community for computer vision tools
- MediaPipe team for facial landmark detection
- Hugging Face for transformer models
- All contributors and testers

## 📈 Roadmap

### Upcoming Features
- [ ] Mobile app version
- [ ] Group therapy sessions
- [ ] Integration with wearable devices
- [ ] Advanced AI therapy techniques
- [ ] Multi-user support
- [ ] Cloud synchronization
- [ ] Voice synthesis for responses
- [ ] Augmented reality relaxation exercises

### Version History
- **v1.0.0**: Initial release with core features
- **v1.1.0**: Added face recognition and voice analysis
- **v1.2.0**: Enhanced counselor connection and data analytics
- **v1.3.0**: Improved UI and added relaxation exercises

## 📧 Support

For support, questions, or feedback:
- Create an issue on GitHub
- Email: support@mentalhealthcompanion.ai
- Documentation: [Link to docs]

---

**Remember**: Your mental health matters. This tool is here to support you, but always seek professional help when needed. 💙
