#!/usr/bin/env python3
"""
Advanced Emotion Detection Test Script
Demonstrates the capabilities of the enhanced emotion detection system
"""

import sys
import os
import json
from datetime import datetime

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from emotion_detector import EmotionDetector

def test_basic_emotion_detection():
    """Test basic emotion detection functionality"""
    print("🧠 Testing Basic Emotion Detection")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='rule_based')
    
    test_cases = [
        "I'm so happy today! This is amazing!",
        "I feel really sad and depressed about everything",
        "I'm absolutely furious about what happened",
        "I'm scared and anxious about the future",
        "Wow! I'm so surprised by this news!",
        "I'm disgusted by this behavior",
        "I feel okay, nothing special",
        "I'm not happy at all with this situation",
        "I'm extremely excited about the trip!",
        "I can't believe this is happening to me"
    ]
    
    for text in test_cases:
        emotion = detector.detect_emotion(text)
        intensity = detector.get_emotion_intensity(text)
        confidence = detector.get_emotion_confidence(text)
        
        print(f"Text: '{text}'")
        print(f"  Emotion: {emotion} | Intensity: {intensity} | Confidence: {confidence:.2f}")
        print()

def test_advanced_features():
    """Test advanced emotion detection features"""
    print("🔬 Testing Advanced Features")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='ensemble')
    
    # Test contextual analysis
    context_tests = [
        "Why am I even trying? Nothing matters anymore.",
        "I love this! This is the best day ever!",
        "What's the point of all this?",
        "OMG! This is incredible!!!",
        "I want to die. I can't go on like this."
    ]
    
    print("Contextual Analysis:")
    for text in context_tests:
        emotion = detector.detect_emotion(text)
        context_scores = detector._analyze_context(text)
        print(f"'{text}' -> {emotion}")
        print(f"  Context scores: {context_scores}")
        print()
    
    # Test linguistic features
    linguistic_tests = [
        "I AM SO ANGRY RIGHT NOW!!!",
        "I... I don't know what to do...",
        "This is soooooo frustrating!",
        "Really? Really? You're kidding me!",
        "I'm fine. Everything is fine."
    ]
    
    print("Linguistic Analysis:")
    for text in linguistic_tests:
        emotion = detector.detect_emotion(text)
        linguistic_scores = detector._analyze_linguistic_features(text)
        intensity = detector._analyze_intensity(text)
        print(f"'{text}' -> {emotion} (intensity: {intensity:.2f})")
        print(f"  Linguistic scores: {linguistic_scores}")
        print()

def test_emotion_probabilities():
    """Test emotion probability distribution"""
    print("📊 Testing Emotion Probabilities")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='ensemble')
    
    test_texts = [
        "I'm feeling really happy and excited!",
        "I'm so sad and depressed about everything",
        "I'm angry and frustrated with this situation",
        "I'm scared and anxious about what might happen",
        "I'm surprised and shocked by this news",
        "I'm disgusted and repulsed by this behavior"
    ]
    
    for text in test_texts:
        probabilities = detector.get_emotion_probabilities(text)
        print(f"Text: '{text}'")
        print("Emotion probabilities:")
        for emotion, prob in sorted(probabilities.items(), key=lambda x: x[1], reverse=True):
            print(f"  {emotion}: {prob:.3f}")
        print()

def test_batch_processing():
    """Test batch emotion detection"""
    print("📦 Testing Batch Processing")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='ensemble')
    
    texts = [
        "I love this new job!",
        "I hate my life right now",
        "I'm excited about the weekend",
        "I'm worried about the exam",
        "I'm surprised by the results",
        "I'm disgusted by the food",
        "I feel neutral about it",
        "I'm thrilled with the news!"
    ]
    
    results = detector.batch_detect_emotions(texts)
    
    for result in results:
        print(f"Text: '{result['text']}'")
        print(f"  Emotion: {result['emotion']}")
        print(f"  Intensity: {result['intensity']}")
        print(f"  Confidence: {result['confidence']:.2f}")
        print()

def test_emotion_statistics():
    """Test emotion statistics calculation"""
    print("📈 Testing Emotion Statistics")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='ensemble')
    
    texts = [
        "I'm happy today",
        "I'm sad about the news",
        "I'm angry at my boss",
        "I'm scared of the dark",
        "I'm surprised by the gift",
        "I'm disgusted by the smell",
        "I feel neutral",
        "I'm happy again",
        "I'm still sad",
        "I'm getting angry"
    ]
    
    stats = detector.get_emotion_statistics(texts)
    
    print(f"Total texts: {stats['total_texts']}")
    print(f"Most common emotion: {stats['most_common_emotion']}")
    print(f"Emotion diversity: {stats['emotion_diversity']:.2f}")
    print("\nEmotion distribution:")
    for emotion, percentage in stats['emotion_percentages'].items():
        print(f"  {emotion}: {percentage:.1f}%")
    print()

def test_model_comparison():
    """Test different model types"""
    print("⚖️  Testing Model Comparison")
    print("=" * 50)
    
    # Create test data
    test_data = [
        {"text": "I'm so happy today!", "emotion": "happy"},
        {"text": "I feel really sad", "emotion": "sad"},
        {"text": "I'm angry about this", "emotion": "angry"},
        {"text": "I'm scared of spiders", "emotion": "fear"},
        {"text": "I'm surprised by this", "emotion": "surprise"},
        {"text": "I'm disgusted by this", "emotion": "disgust"},
        {"text": "I feel okay", "emotion": "neutral"}
    ]
    
    detector = EmotionDetector(model_type='ensemble')
    
    # Test different model types
    model_types = ['rule_based', 'ensemble']
    
    for model_type in model_types:
        print(f"\nTesting {model_type} model:")
        detector.model_type = model_type
        
        correct = 0
        total = len(test_data)
        
        for item in test_data:
            predicted = detector.detect_emotion(item['text'])
            actual = item['emotion']
            if predicted == actual:
                correct += 1
            print(f"  '{item['text']}' -> {predicted} (actual: {actual})")
        
        accuracy = correct / total
        print(f"  Accuracy: {accuracy:.2f} ({correct}/{total})")

def test_crisis_detection():
    """Test crisis detection capabilities"""
    print("🚨 Testing Crisis Detection")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='ensemble')
    
    crisis_texts = [
        "I want to die",
        "I want to kill myself",
        "I hate my life",
        "Nothing matters anymore",
        "I can't go on like this",
        "I'm thinking about ending it all"
    ]
    
    normal_texts = [
        "I'm feeling sad today",
        "I'm angry about work",
        "I'm worried about the future",
        "I'm stressed out",
        "I'm having a bad day"
    ]
    
    print("Crisis texts:")
    for text in crisis_texts:
        emotion = detector.detect_emotion(text)
        context_scores = detector._analyze_context(text)
        print(f"  '{text}' -> {emotion}")
        print(f"    Context scores: {context_scores}")
    
    print("\nNormal texts:")
    for text in normal_texts:
        emotion = detector.detect_emotion(text)
        context_scores = detector._analyze_context(text)
        print(f"  '{text}' -> {emotion}")
        print(f"    Context scores: {context_scores}")

def test_emotion_insights():
    """Test detailed emotion insights"""
    print("🔍 Testing Emotion Insights")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='ensemble')
    
    test_text = "I'm not really happy about this situation, but I guess it could be worse."
    
    insights = detector.get_emotional_insights(test_text)
    
    print(f"Text: '{test_text}'")
    print(f"Primary emotion: {insights['primary_emotion']}")
    print(f"Intensity: {insights['intensity']}")
    print(f"Confidence: {insights['confidence']:.2f}")
    print(f"Sentiment polarity: {insights['sentiment_polarity']:.2f}")
    print("Recommendations:")
    for rec in insights['recommendations']:
        print(f"  - {rec}")

def create_sample_dataset():
    """Create a sample dataset for training"""
    print("📚 Creating Sample Dataset")
    print("=" * 50)
    
    detector = EmotionDetector(model_type='ensemble')
    
    sample_data = [
        {"text": "I'm so happy today!", "emotion": "happy"},
        {"text": "I feel really sad", "emotion": "sad"},
        {"text": "I'm angry about this", "emotion": "angry"},
        {"text": "I'm scared of spiders", "emotion": "fear"},
        {"text": "I'm surprised by this", "emotion": "surprise"},
        {"text": "I'm disgusted by this", "emotion": "disgust"},
        {"text": "I feel okay", "emotion": "neutral"},
        {"text": "I love this!", "emotion": "happy"},
        {"text": "I hate this", "emotion": "angry"},
        {"text": "I'm worried", "emotion": "fear"}
    ]
    
    success = detector.create_emotion_dataset(sample_data, "sample_emotion_dataset.json")
    
    if success:
        print("Sample dataset created successfully!")
        
        # Load and display the dataset
        dataset = detector.load_emotion_dataset("sample_emotion_dataset.json")
        print(f"Dataset contains {len(dataset)} entries")
        
        for item in dataset[:3]:  # Show first 3 entries
            print(f"  Text: '{item['text']}'")
            print(f"  Emotion: {item['emotion']}")
            print(f"  Intensity: {item['intensity']}")
            print(f"  Confidence: {item['confidence']:.2f}")
            print()

def main():
    """Run all tests"""
    print("🚀 Advanced Emotion Detection Test Suite")
    print("=" * 60)
    print(f"Test started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    try:
        test_basic_emotion_detection()
        test_advanced_features()
        test_emotion_probabilities()
        test_batch_processing()
        test_emotion_statistics()
        test_model_comparison()
        test_crisis_detection()
        test_emotion_insights()
        create_sample_dataset()
        
        print("=" * 60)
        print("✅ All tests completed successfully!")
        print(f"Test completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
