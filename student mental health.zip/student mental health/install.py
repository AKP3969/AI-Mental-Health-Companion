#!/usr/bin/env python3
"""
Installation script for AI Mental Health Companion
Handles dependency installation and initial setup
"""

import subprocess
import sys
import os
import platform

def install_requirements():
    """Install required packages"""
    print("Installing required packages...")
    
    try:
        # Upgrade pip first
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
        
        # Install requirements
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        
        print("✅ All packages installed successfully!")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing packages: {e}")
        return False

def check_python_version():
    """Check if Python version is compatible"""
    print("Checking Python version...")
    
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"❌ Python 3.8+ required. Current version: {version.major}.{version.minor}")
        return False
    
    print(f"✅ Python version {version.major}.{version.minor}.{version.micro} is compatible")
    return True

def create_directories():
    """Create necessary directories"""
    print("Creating directories...")
    
    directories = [
        "user_data",
        "models",
        "exports",
        "logs"
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✅ Created directory: {directory}")

def download_models():
    """Download additional models if needed"""
    print("Checking for additional models...")
    
    # Check if dlib shape predictor exists
    shape_predictor_path = "shape_predictor_68_face_landmarks.dat"
    
    if not os.path.exists(shape_predictor_path):
        print("⚠️  Dlib shape predictor not found.")
        print("   For enhanced face analysis, download from:")
        print("   http://dlib.net/files/shape_predictor_68_face_landmarks.dat")
        print("   and place it in the project root directory.")
    else:
        print("✅ Dlib shape predictor found")

def check_system_requirements():
    """Check system requirements"""
    print("Checking system requirements...")
    
    # Check available memory
    try:
        import psutil
        memory = psutil.virtual_memory()
        memory_gb = memory.total / (1024**3)
        
        if memory_gb < 4:
            print(f"⚠️  Low memory detected: {memory_gb:.1f}GB (4GB+ recommended)")
        else:
            print(f"✅ Memory: {memory_gb:.1f}GB")
    except ImportError:
        print("⚠️  psutil not available, cannot check memory")
    
    # Check platform
    system = platform.system()
    print(f"✅ Platform: {system}")

def test_imports():
    """Test if all required modules can be imported"""
    print("Testing imports...")
    
    required_modules = [
        'cv2',
        'numpy',
        'tensorflow',
        'transformers',
        'speech_recognition',
        'pyttsx3',
        'tkinter',
        'PIL',
        'sklearn',
        'pandas',
        'matplotlib',
        'seaborn',
        'requests',
        'flask',
        'mediapipe',
        'dlib'
    ]
    
    failed_imports = []
    
    for module in required_modules:
        try:
            __import__(module)
            print(f"✅ {module}")
        except ImportError as e:
            print(f"❌ {module}: {e}")
            failed_imports.append(module)
    
    if failed_imports:
        print(f"\n⚠️  Failed to import: {', '.join(failed_imports)}")
        print("   Some features may not work properly.")
        return False
    
    print("✅ All modules imported successfully!")
    return True

def main():
    """Main installation process"""
    print("🚀 AI Mental Health Companion - Installation Script")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Check system requirements
    check_system_requirements()
    
    # Create directories
    create_directories()
    
    # Install requirements
    if not install_requirements():
        print("\n❌ Installation failed. Please check the error messages above.")
        sys.exit(1)
    
    # Test imports
    print("\n" + "=" * 50)
    test_imports()
    
    # Check for additional models
    download_models()
    
    print("\n" + "=" * 50)
    print("🎉 Installation completed!")
    print("\nTo run the application:")
    print("  python main.py")
    print("\nFor help:")
    print("  python main.py --help")
    print("\n📖 Read README.md for detailed usage instructions")

if __name__ == "__main__":
    main()
