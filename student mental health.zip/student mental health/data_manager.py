"""
Data Manager Module
Handles user data storage, progress tracking, and analytics
"""

import json
import os
import sqlite3
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from collections import defaultdict

class DataManager:
    def __init__(self, db_path="mental_health_data.db"):
        self.db_path = db_path
        self.init_database()
        
        # Data storage paths
        self.data_dir = "user_data"
        self.journal_path = os.path.join(self.data_dir, "journal_entries.json")
        self.mood_path = os.path.join(self.data_dir, "mood_data.json")
        self.emotion_path = os.path.join(self.data_dir, "emotion_data.json")
        self.progress_path = os.path.join(self.data_dir, "progress_data.json")
        
        # Create data directory if it doesn't exist
        os.makedirs(self.data_dir, exist_ok=True)
    
    def init_database(self):
        """Initialize SQLite database for structured data storage"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create tables
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS mood_entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    mood_score INTEGER NOT NULL,
                    notes TEXT,
                    emotion TEXT,
                    stress_level TEXT
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS journal_entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    entry TEXT NOT NULL,
                    word_count INTEGER,
                    emotion TEXT,
                    sentiment_score REAL
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS emotion_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    text_emotion TEXT,
                    face_emotion TEXT,
                    voice_emotion TEXT,
                    confidence REAL,
                    context TEXT
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS relaxation_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    session_type TEXT NOT NULL,
                    duration_minutes INTEGER,
                    effectiveness_score INTEGER,
                    notes TEXT
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS counselor_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    counselor_name TEXT,
                    duration_minutes INTEGER,
                    message_count INTEGER,
                    satisfaction_score INTEGER,
                    notes TEXT
                )
            ''')
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"Database initialization error: {e}")
    
    def save_mood_entry(self, mood_score, notes="", emotion="", stress_level=""):
        """Save mood entry to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO mood_entries (timestamp, mood_score, notes, emotion, stress_level)
                VALUES (?, ?, ?, ?, ?)
            ''', (datetime.now().isoformat(), mood_score, notes, emotion, stress_level))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            print(f"Error saving mood entry: {e}")
            return False
    
    def get_mood_data(self, days=30):
        """Get mood data for specified number of days"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Calculate date range
            start_date = (datetime.now() - timedelta(days=days)).isoformat()
            
            cursor.execute('''
                SELECT timestamp, mood_score, emotion, stress_level
                FROM mood_entries
                WHERE timestamp >= ?
                ORDER BY timestamp
            ''', (start_date,))
            
            data = cursor.fetchall()
            conn.close()
            
            return data
            
        except Exception as e:
            print(f"Error getting mood data: {e}")
            return []
    
    def save_journal_entry(self, entry, emotion="", sentiment_score=0.0):
        """Save journal entry to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            word_count = len(entry.split())
            
            cursor.execute('''
                INSERT INTO journal_entries (timestamp, entry, word_count, emotion, sentiment_score)
                VALUES (?, ?, ?, ?, ?)
            ''', (datetime.now().isoformat(), entry, word_count, emotion, sentiment_score))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            print(f"Error saving journal entry: {e}")
            return False
    
    def get_journal_entries(self, days=30):
        """Get journal entries for specified number of days"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            start_date = (datetime.now() - timedelta(days=days)).isoformat()
            
            cursor.execute('''
                SELECT timestamp, entry, word_count, emotion, sentiment_score
                FROM journal_entries
                WHERE timestamp >= ?
                ORDER BY timestamp DESC
            ''', (start_date,))
            
            data = cursor.fetchall()
            conn.close()
            
            return data
            
        except Exception as e:
            print(f"Error getting journal entries: {e}")
            return []
    
    def save_emotion_data(self, text_emotion="", face_emotion="", voice_emotion="", 
                         confidence=0.0, context=""):
        """Save emotion data to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO emotion_data (timestamp, text_emotion, face_emotion, voice_emotion, confidence, context)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (datetime.now().isoformat(), text_emotion, face_emotion, voice_emotion, confidence, context))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            print(f"Error saving emotion data: {e}")
            return False
    
    def get_emotion_data(self, days=30):
        """Get emotion data for specified number of days"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            start_date = (datetime.now() - timedelta(days=days)).isoformat()
            
            cursor.execute('''
                SELECT timestamp, text_emotion, face_emotion, voice_emotion, confidence, context
                FROM emotion_data
                WHERE timestamp >= ?
                ORDER BY timestamp
            ''', (start_date,))
            
            data = cursor.fetchall()
            conn.close()
            
            return data
            
        except Exception as e:
            print(f"Error getting emotion data: {e}")
            return []
    
    def save_relaxation_session(self, session_type, duration_minutes, effectiveness_score=0, notes=""):
        """Save relaxation session data"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO relaxation_sessions (timestamp, session_type, duration_minutes, effectiveness_score, notes)
                VALUES (?, ?, ?, ?, ?)
            ''', (datetime.now().isoformat(), session_type, duration_minutes, effectiveness_score, notes))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            print(f"Error saving relaxation session: {e}")
            return False
    
    def save_counselor_session(self, counselor_name, duration_minutes, message_count, 
                              satisfaction_score=0, notes=""):
        """Save counselor session data"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO counselor_sessions (timestamp, counselor_name, duration_minutes, message_count, satisfaction_score, notes)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (datetime.now().isoformat(), counselor_name, duration_minutes, message_count, satisfaction_score, notes))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            print(f"Error saving counselor session: {e}")
            return False
    
    def get_mood_analytics(self, days=30):
        """Get mood analytics and trends"""
        try:
            mood_data = self.get_mood_data(days)
            
            if not mood_data:
                return "No mood data available"
            
            # Convert to DataFrame for analysis
            df = pd.DataFrame(mood_data, columns=['timestamp', 'mood_score', 'emotion', 'stress_level'])
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df['date'] = df['timestamp'].dt.date
            
            # Calculate statistics
            avg_mood = df['mood_score'].mean()
            mood_trend = self.calculate_trend(df['mood_score'])
            
            # Emotion distribution
            emotion_counts = df['emotion'].value_counts()
            
            # Stress level distribution
            stress_counts = df['stress_level'].value_counts()
            
            # Daily mood averages
            daily_mood = df.groupby('date')['mood_score'].mean()
            
            analytics = {
                'average_mood': round(avg_mood, 2),
                'mood_trend': mood_trend,
                'emotion_distribution': emotion_counts.to_dict(),
                'stress_distribution': stress_counts.to_dict(),
                'daily_mood': daily_mood.to_dict(),
                'total_entries': len(mood_data),
                'days_tracked': len(daily_mood)
            }
            
            return analytics
            
        except Exception as e:
            print(f"Error calculating mood analytics: {e}")
            return "Error calculating mood analytics"
    
    def calculate_trend(self, values):
        """Calculate trend direction from a series of values"""
        if len(values) < 2:
            return "insufficient_data"
        
        # Simple linear trend calculation
        x = np.arange(len(values))
        y = np.array(values)
        
        # Calculate slope
        slope = np.polyfit(x, y, 1)[0]
        
        if slope > 0.1:
            return "improving"
        elif slope < -0.1:
            return "declining"
        else:
            return "stable"
    
    def get_emotion_analytics(self, days=30):
        """Get emotion analytics and patterns"""
        try:
            emotion_data = self.get_emotion_data(days)
            
            if not emotion_data:
                return "No emotion data available"
            
            # Convert to DataFrame
            df = pd.DataFrame(emotion_data, columns=['timestamp', 'text_emotion', 'face_emotion', 'voice_emotion', 'confidence', 'context'])
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Analyze emotion patterns
            text_emotions = df['text_emotion'].value_counts()
            face_emotions = df['face_emotion'].value_counts()
            voice_emotions = df['voice_emotion'].value_counts()
            
            # Calculate average confidence
            avg_confidence = df['confidence'].mean()
            
            # Emotion consistency (how often emotions match across modalities)
            consistency = self.calculate_emotion_consistency(df)
            
            analytics = {
                'text_emotions': text_emotions.to_dict(),
                'face_emotions': face_emotions.to_dict(),
                'voice_emotions': voice_emotions.to_dict(),
                'average_confidence': round(avg_confidence, 2),
                'emotion_consistency': round(consistency, 2),
                'total_entries': len(emotion_data)
            }
            
            return analytics
            
        except Exception as e:
            print(f"Error calculating emotion analytics: {e}")
            return "Error calculating emotion analytics"
    
    def calculate_emotion_consistency(self, df):
        """Calculate consistency between different emotion detection methods"""
        if len(df) == 0:
            return 0.0
        
        consistent_count = 0
        total_count = 0
        
        for _, row in df.iterrows():
            emotions = [row['text_emotion'], row['face_emotion'], row['voice_emotion']]
            emotions = [e for e in emotions if e and e != 'neutral']  # Filter out empty/neutral
            
            if len(emotions) >= 2:
                total_count += 1
                if len(set(emotions)) == 1:  # All emotions are the same
                    consistent_count += 1
        
        return (consistent_count / total_count) * 100 if total_count > 0 else 0.0
    
    def get_progress_summary(self, days=30):
        """Get overall progress summary"""
        try:
            mood_analytics = self.get_mood_analytics(days)
            emotion_analytics = self.get_emotion_analytics(days)
            
            # Get journal statistics
            journal_entries = self.get_journal_entries(days)
            journal_word_count = sum(entry[2] for entry in journal_entries)  # word_count is index 2
            
            # Get relaxation session statistics
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            start_date = (datetime.now() - timedelta(days=days)).isoformat()
            
            cursor.execute('''
                SELECT COUNT(*), AVG(duration_minutes), AVG(effectiveness_score)
                FROM relaxation_sessions
                WHERE timestamp >= ?
            ''', (start_date,))
            
            relaxation_stats = cursor.fetchone()
            
            cursor.execute('''
                SELECT COUNT(*), AVG(duration_minutes), AVG(satisfaction_score)
                FROM counselor_sessions
                WHERE timestamp >= ?
            ''', (start_date,))
            
            counselor_stats = cursor.fetchone()
            
            conn.close()
            
            summary = {
                'period_days': days,
                'mood_analytics': mood_analytics,
                'emotion_analytics': emotion_analytics,
                'journal_entries': len(journal_entries),
                'journal_words': journal_word_count,
                'relaxation_sessions': relaxation_stats[0] or 0,
                'avg_relaxation_duration': round(relaxation_stats[1] or 0, 1),
                'avg_relaxation_effectiveness': round(relaxation_stats[2] or 0, 1),
                'counselor_sessions': counselor_stats[0] or 0,
                'avg_counselor_duration': round(counselor_stats[1] or 0, 1),
                'avg_counselor_satisfaction': round(counselor_stats[2] or 0, 1)
            }
            
            return summary
            
        except Exception as e:
            print(f"Error generating progress summary: {e}")
            return "Error generating progress summary"
    
    def create_mood_chart(self, days=30, save_path="mood_chart.png"):
        """Create mood trend chart"""
        try:
            mood_data = self.get_mood_data(days)
            
            if not mood_data:
                return False
            
            # Convert to DataFrame
            df = pd.DataFrame(mood_data, columns=['timestamp', 'mood_score', 'emotion', 'stress_level'])
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df['date'] = df['timestamp'].dt.date
            
            # Create daily averages
            daily_mood = df.groupby('date')['mood_score'].mean()
            
            # Create chart
            plt.figure(figsize=(12, 6))
            plt.plot(daily_mood.index, daily_mood.values, marker='o', linewidth=2, markersize=6)
            plt.title(f'Mood Trend - Last {days} Days', fontsize=16, fontweight='bold')
            plt.xlabel('Date', fontsize=12)
            plt.ylabel('Mood Score (1-10)', fontsize=12)
            plt.grid(True, alpha=0.3)
            plt.xticks(rotation=45)
            plt.tight_layout()
            
            # Save chart
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            return True
            
        except Exception as e:
            print(f"Error creating mood chart: {e}")
            return False
    
    def create_emotion_chart(self, days=30, save_path="emotion_chart.png"):
        """Create emotion distribution chart"""
        try:
            emotion_data = self.get_emotion_data(days)
            
            if not emotion_data:
                return False
            
            # Convert to DataFrame
            df = pd.DataFrame(emotion_data, columns=['timestamp', 'text_emotion', 'face_emotion', 'voice_emotion', 'confidence', 'context'])
            
            # Count emotions
            all_emotions = []
            for emotion in ['text_emotion', 'face_emotion', 'voice_emotion']:
                all_emotions.extend(df[emotion].dropna().tolist())
            
            emotion_counts = pd.Series(all_emotions).value_counts()
            
            # Create pie chart
            plt.figure(figsize=(10, 8))
            plt.pie(emotion_counts.values, labels=emotion_counts.index, autopct='%1.1f%%', startangle=90)
            plt.title(f'Emotion Distribution - Last {days} Days', fontsize=16, fontweight='bold')
            plt.axis('equal')
            
            # Save chart
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            return True
            
        except Exception as e:
            print(f"Error creating emotion chart: {e}")
            return False
    
    def export_data(self, filename="mental_health_export.json"):
        """Export all user data to JSON file"""
        try:
            export_data = {
                'export_timestamp': datetime.now().isoformat(),
                'mood_data': self.get_mood_data(365),  # Last year
                'journal_entries': self.get_journal_entries(365),
                'emotion_data': self.get_emotion_data(365),
                'progress_summary': self.get_progress_summary(365)
            }
            
            with open(filename, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            return True
            
        except Exception as e:
            print(f"Error exporting data: {e}")
            return False
    
    def cleanup_old_data(self, days_to_keep=365):
        """Clean up old data to save space"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cutoff_date = (datetime.now() - timedelta(days=days_to_keep)).isoformat()
            
            # Delete old data from all tables
            tables = ['mood_entries', 'journal_entries', 'emotion_data', 'relaxation_sessions', 'counselor_sessions']
            
            for table in tables:
                cursor.execute(f'DELETE FROM {table} WHERE timestamp < ?', (cutoff_date,))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            print(f"Error cleaning up old data: {e}")
            return False
