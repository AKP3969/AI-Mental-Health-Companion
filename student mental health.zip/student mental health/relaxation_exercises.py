"""
Relaxation Exercises Module
Provides various relaxation techniques including breathing exercises, music, and journaling
"""

import tkinter as tk
from tkinter import messagebox
import threading
import time
import json
import os
from datetime import datetime
import pygame
import random
import math

class RelaxationExercises:
    def __init__(self):
        self.is_breathing_active = False
        self.breathing_thread = None
        self.music_playing = False
        self.current_exercise = None
        
        # Initialize pygame mixer for music
        try:
            pygame.mixer.init()
        except:
            print("Pygame mixer not available. Music features will be limited.")
        
        # Breathing exercise patterns
        self.breathing_patterns = {
            '4-4-4-4': {'inhale': 4, 'hold': 4, 'exhale': 4, 'pause': 4},
            '4-7-8': {'inhale': 4, 'hold': 7, 'exhale': 8, 'pause': 0},
            'box_breathing': {'inhale': 4, 'hold': 4, 'exhale': 4, 'pause': 4},
            'triangle': {'inhale': 4, 'hold': 0, 'exhale': 4, 'pause': 0},
            'calm': {'inhale': 3, 'hold': 2, 'exhale': 5, 'pause': 2}
        }
        
        # Relaxation music tracks (placeholder - in real implementation, you'd have actual audio files)
        self.music_tracks = [
            'nature_sounds.wav',
            'meditation_bells.wav',
            'ocean_waves.wav',
            'rain_sounds.wav',
            'forest_ambience.wav'
        ]
        
        # Journaling prompts
        self.journal_prompts = [
            "What are three things you're grateful for today?",
            "Describe a moment today when you felt peaceful or content.",
            "What emotions did you experience today, and what might have triggered them?",
            "Write about something that made you smile today.",
            "What would you like to let go of from today?",
            "Describe your ideal peaceful place. What does it look like, sound like, feel like?",
            "What self-care activity would you like to do for yourself today?",
            "Write about a challenge you overcame today, no matter how small.",
            "What are you looking forward to tomorrow?",
            "Describe how you're feeling right now in this moment."
        ]
    
    def start_breathing_exercise(self, canvas, pattern='4-4-4-4'):
        """Start a breathing exercise with visual guidance"""
        if self.is_breathing_active:
            self.stop_breathing_exercise()
            return
        
        self.is_breathing_active = True
        self.current_exercise = pattern
        
        # Clear canvas
        canvas.delete("all")
        
        # Start breathing thread
        self.breathing_thread = threading.Thread(
            target=self.breathing_loop, 
            args=(canvas, pattern), 
            daemon=True
        )
        self.breathing_thread.start()
    
    def breathing_loop(self, canvas, pattern):
        """Main breathing exercise loop"""
        pattern_data = self.breathing_patterns[pattern]
        
        while self.is_breathing_active:
            try:
                # Inhale phase
                self.draw_breathing_circle(canvas, "Inhale", "green", pattern_data['inhale'])
                if not self.is_breathing_active:
                    break
                
                # Hold phase
                if pattern_data['hold'] > 0:
                    self.draw_breathing_circle(canvas, "Hold", "blue", pattern_data['hold'])
                    if not self.is_breathing_active:
                        break
                
                # Exhale phase
                self.draw_breathing_circle(canvas, "Exhale", "red", pattern_data['exhale'])
                if not self.is_breathing_active:
                    break
                
                # Pause phase
                if pattern_data['pause'] > 0:
                    self.draw_breathing_circle(canvas, "Pause", "gray", pattern_data['pause'])
                    if not self.is_breathing_active:
                        break
                
            except Exception as e:
                print(f"Breathing exercise error: {e}")
                break
        
        # Clear canvas when done
        canvas.delete("all")
        canvas.create_text(150, 100, text="Breathing exercise completed!", 
                          font=("Arial", 16), fill="green")
    
    def draw_breathing_circle(self, canvas, phase, color, duration):
        """Draw breathing circle with animation"""
        canvas_width = canvas.winfo_width()
        canvas_height = canvas.winfo_height()
        
        if canvas_width <= 1 or canvas_height <= 1:
            return
        
        center_x = canvas_width // 2
        center_y = canvas_height // 2
        
        # Clear canvas
        canvas.delete("all")
        
        # Draw phase text
        canvas.create_text(center_x, 50, text=phase, 
                          font=("Arial", 20, "bold"), fill=color)
        
        # Draw countdown
        for i in range(duration, 0, -1):
            if not self.is_breathing_active:
                break
            
            # Calculate circle size based on phase
            if phase == "Inhale":
                # Circle grows during inhale
                size = int(20 + (i / duration) * 80)
            elif phase == "Exhale":
                # Circle shrinks during exhale
                size = int(100 - (i / duration) * 80)
            else:
                # Circle stays same size during hold/pause
                size = 100
            
            # Clear and redraw
            canvas.delete("circle")
            canvas.create_oval(center_x - size, center_y - size, 
                             center_x + size, center_y + size,
                             fill=color, outline="black", width=2, tags="circle")
            
            # Draw countdown number
            canvas.create_text(center_x, center_y, text=str(i), 
                              font=("Arial", 24, "bold"), fill="white", tags="circle")
            
            # Update canvas
            canvas.update()
            time.sleep(1)
    
    def stop_breathing_exercise(self):
        """Stop the current breathing exercise"""
        self.is_breathing_active = False
        if self.breathing_thread:
            self.breathing_thread.join(timeout=1)
    
    def play_relaxing_music(self):
        """Play relaxing music (placeholder implementation)"""
        if self.music_playing:
            self.stop_music()
            return
        
        try:
            # In a real implementation, you would load actual audio files
            # For now, we'll simulate music playing
            self.music_playing = True
            
            # Start music thread
            music_thread = threading.Thread(target=self.music_loop, daemon=True)
            music_thread.start()
            
            messagebox.showinfo("Music", "Relaxing music started! (Simulated)")
            
        except Exception as e:
            messagebox.showerror("Error", f"Could not start music: {e}")
    
    def music_loop(self):
        """Music playing loop (simulated)"""
        while self.music_playing:
            # In a real implementation, this would play actual audio
            time.sleep(1)
    
    def stop_music(self):
        """Stop the music"""
        self.music_playing = False
        try:
            pygame.mixer.music.stop()
        except:
            pass
    
    def get_journal_prompt(self):
        """Get a random journaling prompt"""
        return random.choice(self.journal_prompts)
    
    def save_journal_entry(self, entry, filename="journal_entries.json"):
        """Save journal entry to file"""
        try:
            # Load existing entries
            entries = []
            if os.path.exists(filename):
                with open(filename, 'r') as f:
                    entries = json.load(f)
            
            # Add new entry
            new_entry = {
                'timestamp': datetime.now().isoformat(),
                'entry': entry,
                'word_count': len(entry.split())
            }
            entries.append(new_entry)
            
            # Save back to file
            with open(filename, 'w') as f:
                json.dump(entries, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error saving journal entry: {e}")
            return False
    
    def load_journal_entries(self, filename="journal_entries.json"):
        """Load journal entries from file"""
        try:
            if os.path.exists(filename):
                with open(filename, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            print(f"Error loading journal entries: {e}")
            return []
    
    def get_journal_stats(self):
        """Get journaling statistics"""
        entries = self.load_journal_entries()
        
        if not entries:
            return "No journal entries yet."
        
        total_entries = len(entries)
        total_words = sum(entry['word_count'] for entry in entries)
        
        # Get entries from last 7 days
        week_ago = datetime.now().timestamp() - (7 * 24 * 60 * 60)
        recent_entries = [
            entry for entry in entries 
            if datetime.fromisoformat(entry['timestamp']).timestamp() > week_ago
        ]
        
        stats = f"Total entries: {total_entries}\n"
        stats += f"Total words: {total_words}\n"
        stats += f"Entries this week: {len(recent_entries)}\n"
        stats += f"Average words per entry: {total_words // total_entries if total_entries > 0 else 0}"
        
        return stats
    
    def start_progressive_muscle_relaxation(self, canvas):
        """Start progressive muscle relaxation exercise"""
        if self.is_breathing_active:
            self.stop_breathing_exercise()
        
        self.is_breathing_active = True
        self.current_exercise = "progressive_muscle"
        
        # Start PMR thread
        pmr_thread = threading.Thread(
            target=self.progressive_muscle_loop, 
            args=(canvas,), 
            daemon=True
        )
        pmr_thread.start()
    
    def progressive_muscle_loop(self, canvas):
        """Progressive muscle relaxation exercise loop"""
        muscle_groups = [
            "Feet and calves",
            "Thighs and glutes", 
            "Abdomen and core",
            "Hands and forearms",
            "Upper arms and shoulders",
            "Face and jaw",
            "Neck and head"
        ]
        
        canvas.delete("all")
        canvas.create_text(150, 50, text="Progressive Muscle Relaxation", 
                          font=("Arial", 16, "bold"), fill="blue")
        
        for i, muscle_group in enumerate(muscle_groups):
            if not self.is_breathing_active:
                break
            
            # Tense phase
            canvas.delete("instruction")
            canvas.create_text(150, 100, text=f"Tense: {muscle_group}", 
                              font=("Arial", 14), fill="red", tags="instruction")
            canvas.create_text(150, 130, text="Hold for 5 seconds...", 
                              font=("Arial", 12), fill="red", tags="instruction")
            
            for j in range(5, 0, -1):
                if not self.is_breathing_active:
                    break
                canvas.create_text(150, 160, text=str(j), 
                                  font=("Arial", 20, "bold"), fill="red", tags="instruction")
                canvas.update()
                time.sleep(1)
            
            # Relax phase
            canvas.delete("instruction")
            canvas.create_text(150, 100, text=f"Relax: {muscle_group}", 
                              font=("Arial", 14), fill="green", tags="instruction")
            canvas.create_text(150, 130, text="Feel the tension release...", 
                              font=("Arial", 12), fill="green", tags="instruction")
            
            for j in range(10, 0, -1):
                if not self.is_breathing_active:
                    break
                canvas.create_text(150, 160, text=str(j), 
                                  font=("Arial", 20, "bold"), fill="green", tags="instruction")
                canvas.update()
                time.sleep(1)
        
        # Completion message
        canvas.delete("all")
        canvas.create_text(150, 100, text="Progressive Muscle Relaxation Complete!", 
                          font=("Arial", 16), fill="green")
        canvas.create_text(150, 130, text="Notice how relaxed your body feels.", 
                          font=("Arial", 12), fill="blue")
        
        self.is_breathing_active = False
    
    def start_meditation_timer(self, duration_minutes=5):
        """Start a meditation timer"""
        duration_seconds = duration_minutes * 60
        
        # Create meditation window
        med_window = tk.Toplevel()
        med_window.title("Meditation Timer")
        med_window.geometry("300x200")
        med_window.configure(bg='#f0f0f0')
        
        # Timer display
        timer_label = tk.Label(med_window, text="", font=("Arial", 24, "bold"), 
                              bg='#f0f0f0', fg='blue')
        timer_label.pack(pady=20)
        
        # Progress bar
        progress = tk.Canvas(med_window, width=250, height=20, bg='white')
        progress.pack(pady=10)
        
        # Instructions
        instructions = tk.Label(med_window, 
                              text="Sit comfortably and focus on your breath.\nClose your eyes and let go of thoughts.",
                              font=("Arial", 12), bg='#f0f0f0', fg='black')
        instructions.pack(pady=10)
        
        # Start timer
        self.meditation_timer_loop(med_window, timer_label, progress, duration_seconds)
    
    def meditation_timer_loop(self, window, timer_label, progress, duration_seconds):
        """Meditation timer loop"""
        start_time = time.time()
        
        while True:
            elapsed = time.time() - start_time
            remaining = max(0, duration_seconds - elapsed)
            
            if remaining <= 0:
                timer_label.config(text="Meditation Complete!", fg='green')
                progress.create_rectangle(0, 0, 250, 20, fill='green')
                break
            
            # Update timer display
            minutes = int(remaining // 60)
            seconds = int(remaining % 60)
            timer_label.config(text=f"{minutes:02d}:{seconds:02d}")
            
            # Update progress bar
            progress.delete("all")
            progress_width = int((elapsed / duration_seconds) * 250)
            progress.create_rectangle(0, 0, progress_width, 20, fill='blue')
            
            window.update()
            time.sleep(1)
    
    def get_breathing_patterns(self):
        """Get available breathing patterns"""
        return list(self.breathing_patterns.keys())
    
    def get_breathing_description(self, pattern):
        """Get description of a breathing pattern"""
        descriptions = {
            '4-4-4-4': 'Equal breathing: Inhale for 4, hold for 4, exhale for 4, pause for 4',
            '4-7-8': 'Calming breath: Inhale for 4, hold for 7, exhale for 8',
            'box_breathing': 'Box breathing: Equal inhale, hold, exhale, pause (4 counts each)',
            'triangle': 'Triangle breathing: Inhale for 4, exhale for 4 (no holds)',
            'calm': 'Calm breathing: Gentle 3-2-5-2 pattern for relaxation'
        }
        return descriptions.get(pattern, 'Unknown pattern')
    
    def cleanup(self):
        """Cleanup resources"""
        self.stop_breathing_exercise()
        self.stop_music()
