#!/usr/bin/env python3
"""
Demo script for AI Mental Health Companion
Tests core functionality without GUI
"""

import sys
import os
from datetime import datetime

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_emotion_detection():
    """Test emotion detection functionality"""
    print("🧠 Testing Emotion Detection...")
    
    try:
        from emotion_detector import EmotionDetector
        
        detector = EmotionDetector()
        
        test_messages = [
            "I'm feeling really happy today!",
            "I'm so sad and depressed",
            "I'm angry about what happened",
            "I'm scared and anxious",
            "I'm surprised by the news",
            "I feel neutral about this"
        ]
        
        for message in test_messages:
            emotion = detector.detect_emotion(message)
            intensity = detector.get_emotion_intensity(message)
            confidence = detector.get_emotion_confidence(message)
            
            print(f"  '{message}' -> {emotion} ({intensity}, {confidence:.2f})")
        
        print("✅ Emotion detection working!")
        return True
        
    except Exception as e:
        print(f"❌ Emotion detection error: {e}")
        return False

def test_chatbot():
    """Test chatbot functionality"""
    print("\n💬 Testing Chatbot...")
    
    try:
        from chatbot import MentalHealthChatbot
        
        chatbot = MentalHealthChatbot()
        
        test_messages = [
            "Hello, I'm feeling anxious",
            "I'm having a really bad day",
            "I feel overwhelmed with work",
            "I'm grateful for my friends"
        ]
        
        for message in test_messages:
            response = chatbot.get_response(message, "neutral", "neutral")
            print(f"  User: {message}")
            print(f"  Bot: {response[:100]}...")
            print()
        
        print("✅ Chatbot working!")
        return True
        
    except Exception as e:
        print(f"❌ Chatbot error: {e}")
        return False

def test_data_manager():
    """Test data management functionality"""
    print("\n📊 Testing Data Manager...")
    
    try:
        from data_manager import DataManager
        
        data_manager = DataManager("test_data.db")
        
        # Test mood entry
        data_manager.save_mood_entry(7, "Feeling good today", "happy", "low")
        
        # Test journal entry
        data_manager.save_journal_entry("Today was a good day. I felt productive and happy.", "happy", 0.8)
        
        # Test emotion data
        data_manager.save_emotion_data("happy", "happy", "neutral", 0.9, "test")
        
        # Get analytics
        mood_analytics = data_manager.get_mood_analytics(7)
        print(f"  Mood analytics: {mood_analytics}")
        
        # Clean up test database
        os.remove("test_data.db")
        
        print("✅ Data manager working!")
        return True
        
    except Exception as e:
        print(f"❌ Data manager error: {e}")
        return False

def test_relaxation_exercises():
    """Test relaxation exercises functionality"""
    print("\n🧘 Testing Relaxation Exercises...")
    
    try:
        from relaxation_exercises import RelaxationExercises
        
        exercises = RelaxationExercises()
        
        # Test journal prompt
        prompt = exercises.get_journal_prompt()
        print(f"  Journal prompt: {prompt}")
        
        # Test breathing patterns
        patterns = exercises.get_breathing_patterns()
        print(f"  Available patterns: {patterns}")
        
        # Test pattern description
        for pattern in patterns[:2]:  # Test first 2 patterns
            description = exercises.get_breathing_description(pattern)
            print(f"  {pattern}: {description}")
        
        print("✅ Relaxation exercises working!")
        return True
        
    except Exception as e:
        print(f"❌ Relaxation exercises error: {e}")
        return False

def test_counselor_connection():
    """Test counselor connection functionality"""
    print("\n👨‍⚕️ Testing Counselor Connection...")
    
    try:
        from counselor_connection import CounselorConnection
        
        counselor = CounselorConnection()
        
        # Test connection
        success = counselor.connect()
        print(f"  Connection test: {'Success' if success else 'Failed'}")
        
        # Test message sending
        if success:
            response = counselor.send_message("I'm feeling anxious about my exams")
            print(f"  Counselor response: {response[:100]}...")
        
        # Test available counselors
        counselors = counselor.get_available_counselors()
        print(f"  Available counselors: {len(counselors)}")
        
        # Clean up
        counselor.disconnect()
        
        print("✅ Counselor connection working!")
        return True
        
    except Exception as e:
        print(f"❌ Counselor connection error: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 AI Mental Health Companion - Demo & Test")
    print("=" * 50)
    
    tests = [
        test_emotion_detection,
        test_chatbot,
        test_data_manager,
        test_relaxation_exercises,
        test_counselor_connection
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ Test failed with exception: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! The application should work correctly.")
        print("\nTo run the full application:")
        print("  python main.py")
    else:
        print("⚠️  Some tests failed. Check the error messages above.")
        print("   You may need to install missing dependencies or fix configuration issues.")
    
    print("\n📖 For detailed setup instructions, see README.md")

if __name__ == "__main__":
    main()
