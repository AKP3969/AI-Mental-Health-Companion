"""
Speech Processing Module
Handles speech-to-text conversion and voice emotion analysis
"""

import speech_recognition as sr
import pyttsx3
import numpy as np
import librosa
import soundfile as sf
import tempfile
import os
from scipy import signal
from scipy.fft import fft, fftfreq
import threading
import queue
import time

class SpeechProcessor:
    def __init__(self):
        # Initialize speech recognition
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()
        
        # Initialize text-to-speech
        self.tts_engine = pyttsx3.init()
        self.setup_tts()
        
        # Audio processing parameters
        self.sample_rate = 22050
        self.frame_length = 1024
        self.hop_length = 512
        
        # Voice emotion detection parameters
        self.voice_emotions = {
            'happy': {'pitch_range': (200, 400), 'energy': 0.7, 'tempo': 1.2},
            'sad': {'pitch_range': (100, 250), 'energy': 0.3, 'tempo': 0.8},
            'angry': {'pitch_range': (150, 350), 'energy': 0.9, 'tempo': 1.4},
            'fear': {'pitch_range': (200, 500), 'energy': 0.8, 'tempo': 1.3},
            'surprise': {'pitch_range': (250, 450), 'energy': 0.8, 'tempo': 1.1},
            'neutral': {'pitch_range': (150, 300), 'energy': 0.5, 'tempo': 1.0}
        }
        
        # Audio queue for processing
        self.audio_queue = queue.Queue()
        self.is_listening = False
        
        # Calibrate microphone
        self.calibrate_microphone()
    
    def setup_tts(self):
        """Setup text-to-speech engine"""
        voices = self.tts_engine.getProperty('voices')
        if voices:
            # Use a female voice if available
            for voice in voices:
                if 'female' in voice.name.lower() or 'zira' in voice.name.lower():
                    self.tts_engine.setProperty('voice', voice.id)
                    break
        
        # Set speech rate and volume
        self.tts_engine.setProperty('rate', 150)  # Speed of speech
        self.tts_engine.setProperty('volume', 0.8)  # Volume level
    
    def calibrate_microphone(self):
        """Calibrate microphone for ambient noise"""
        try:
            with self.microphone as source:
                print("Calibrating microphone...")
                self.recognizer.adjust_for_ambient_noise(source, duration=2)
                print("Microphone calibrated.")
        except Exception as e:
            print(f"Microphone calibration error: {e}")
    
    def listen(self, timeout=5, phrase_time_limit=5):
        """Listen for speech input"""
        try:
            with self.microphone as source:
                print("Listening...")
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
            
            # Convert speech to text
            text = self.recognizer.recognize_google(audio)
            print(f"Recognized: {text}")
            
            # Analyze voice emotion
            emotion = self.analyze_voice_emotion(audio)
            print(f"Detected voice emotion: {emotion}")
            
            return text
            
        except sr.WaitTimeoutError:
            print("No speech detected within timeout period.")
            return None
        except sr.UnknownValueError:
            print("Could not understand the speech.")
            return None
        except sr.RequestError as e:
            print(f"Speech recognition service error: {e}")
            return None
        except Exception as e:
            print(f"Speech recognition error: {e}")
            return None
    
    def listen_continuous(self, callback=None):
        """Listen continuously for speech input"""
        self.is_listening = True
        
        def listen_loop():
            while self.is_listening:
                try:
                    text = self.listen(timeout=1, phrase_time_limit=3)
                    if text and callback:
                        callback(text)
                except Exception as e:
                    print(f"Continuous listening error: {e}")
                time.sleep(0.1)
        
        threading.Thread(target=listen_loop, daemon=True).start()
    
    def stop_listening(self):
        """Stop continuous listening"""
        self.is_listening = False
    
    def speak(self, text):
        """Convert text to speech"""
        try:
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
        except Exception as e:
            print(f"Text-to-speech error: {e}")
    
    def analyze_voice_emotion(self, audio_data):
        """Analyze emotion from voice characteristics"""
        try:
            # Convert audio data to numpy array
            audio_array = np.frombuffer(audio_data.frame_data, dtype=np.int16)
            
            # Convert to float and normalize
            audio_float = audio_array.astype(np.float32) / 32768.0
            
            # Save to temporary file for librosa processing
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                sf.write(temp_file.name, audio_float, audio_data.sample_rate)
                
                # Load with librosa
                y, sr = librosa.load(temp_file.name, sr=self.sample_rate)
                
                # Clean up temporary file
                os.unlink(temp_file.name)
            
            # Extract voice features
            features = self.extract_voice_features(y, sr)
            
            # Classify emotion
            emotion = self.classify_voice_emotion(features)
            
            return emotion
            
        except Exception as e:
            print(f"Voice emotion analysis error: {e}")
            return "neutral"
    
    def extract_voice_features(self, audio, sr):
        """Extract voice features for emotion analysis"""
        features = {}
        
        # Pitch (fundamental frequency)
        pitches, magnitudes = librosa.piptrack(y=audio, sr=sr, threshold=0.1)
        pitch_values = []
        for t in range(pitches.shape[1]):
            index = magnitudes[:, t].argmax()
            pitch = pitches[index, t]
            if pitch > 0:
                pitch_values.append(pitch)
        
        if pitch_values:
            features['pitch_mean'] = np.mean(pitch_values)
            features['pitch_std'] = np.std(pitch_values)
            features['pitch_range'] = np.max(pitch_values) - np.min(pitch_values)
        else:
            features['pitch_mean'] = 0
            features['pitch_std'] = 0
            features['pitch_range'] = 0
        
        # Energy (volume)
        features['energy'] = np.mean(librosa.feature.rms(y=audio)[0])
        
        # Spectral features
        spectral_centroids = librosa.feature.spectral_centroid(y=audio, sr=sr)[0]
        features['spectral_centroid'] = np.mean(spectral_centroids)
        
        # Zero crossing rate (speech rate indicator)
        zcr = librosa.feature.zero_crossing_rate(audio)[0]
        features['zcr'] = np.mean(zcr)
        
        # Tempo
        tempo, _ = librosa.beat.beat_track(y=audio, sr=sr)
        features['tempo'] = tempo
        
        # MFCC features
        mfccs = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=13)
        features['mfcc_mean'] = np.mean(mfccs, axis=1)
        
        # Spectral rolloff
        rolloff = librosa.feature.spectral_rolloff(y=audio, sr=sr)[0]
        features['spectral_rolloff'] = np.mean(rolloff)
        
        return features
    
    def classify_voice_emotion(self, features):
        """Classify emotion based on voice features"""
        pitch_mean = features.get('pitch_mean', 200)
        energy = features.get('energy', 0.5)
        tempo = features.get('tempo', 120)
        
        # Normalize features
        pitch_normalized = min(1.0, max(0.0, (pitch_mean - 100) / 400))
        energy_normalized = min(1.0, max(0.0, energy * 10))
        tempo_normalized = min(1.0, max(0.0, (tempo - 60) / 120))
        
        # Calculate similarity to each emotion
        similarities = {}
        
        for emotion, params in self.voice_emotions.items():
            pitch_range = params['pitch_range']
            target_energy = params['energy']
            target_tempo = params['tempo']
            
            # Calculate pitch similarity
            pitch_center = (pitch_range[0] + pitch_range[1]) / 2
            pitch_similarity = 1.0 - abs(pitch_mean - pitch_center) / 200
            
            # Calculate energy similarity
            energy_similarity = 1.0 - abs(energy - target_energy)
            
            # Calculate tempo similarity
            tempo_similarity = 1.0 - abs(tempo - target_tempo) / 60
            
            # Combined similarity
            similarities[emotion] = (
                pitch_similarity * 0.4 +
                energy_similarity * 0.3 +
                tempo_similarity * 0.3
            )
        
        # Return emotion with highest similarity
        return max(similarities, key=similarities.get)
    
    def get_voice_stress_level(self, audio_data):
        """Analyze stress level from voice characteristics"""
        try:
            # Convert audio data to numpy array
            audio_array = np.frombuffer(audio_data.frame_data, dtype=np.int16)
            audio_float = audio_array.astype(np.float32) / 32768.0
            
            # Save to temporary file
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                sf.write(temp_file.name, audio_float, audio_data.sample_rate)
                y, sr = librosa.load(temp_file.name, sr=self.sample_rate)
                os.unlink(temp_file.name)
            
            # Extract stress indicators
            stress_indicators = self.extract_stress_indicators(y, sr)
            
            # Calculate stress level
            stress_level = self.calculate_stress_level(stress_indicators)
            
            return stress_level
            
        except Exception as e:
            print(f"Voice stress analysis error: {e}")
            return "low"
    
    def extract_stress_indicators(self, audio, sr):
        """Extract stress indicators from voice"""
        indicators = {}
        
        # Jitter (pitch variation)
        pitches, magnitudes = librosa.piptrack(y=audio, sr=sr, threshold=0.1)
        pitch_values = []
        for t in range(pitches.shape[1]):
            index = magnitudes[:, t].argmax()
            pitch = pitches[index, t]
            if pitch > 0:
                pitch_values.append(pitch)
        
        if len(pitch_values) > 1:
            jitter = np.std(np.diff(pitch_values))
            indicators['jitter'] = jitter
        else:
            indicators['jitter'] = 0
        
        # Shimmer (amplitude variation)
        rms = librosa.feature.rms(y=audio)[0]
        if len(rms) > 1:
            shimmer = np.std(np.diff(rms))
            indicators['shimmer'] = shimmer
        else:
            indicators['shimmer'] = 0
        
        # Voice quality
        spectral_centroids = librosa.feature.spectral_centroid(y=audio, sr=sr)[0]
        indicators['spectral_centroid_std'] = np.std(spectral_centroids)
        
        # Harmonic-to-noise ratio
        try:
            harmonic, percussive = librosa.effects.hpss(audio)
            hnr = np.mean(harmonic) / (np.mean(percussive) + 1e-10)
            indicators['hnr'] = hnr
        except:
            indicators['hnr'] = 1.0
        
        return indicators
    
    def calculate_stress_level(self, indicators):
        """Calculate stress level from indicators"""
        jitter = indicators.get('jitter', 0)
        shimmer = indicators.get('shimmer', 0)
        spectral_centroid_std = indicators.get('spectral_centroid_std', 0)
        hnr = indicators.get('hnr', 1.0)
        
        # Normalize indicators
        jitter_norm = min(1.0, jitter / 50)
        shimmer_norm = min(1.0, shimmer / 0.1)
        spectral_norm = min(1.0, spectral_centroid_std / 1000)
        hnr_norm = max(0.0, min(1.0, (2.0 - hnr) / 2.0))
        
        # Calculate stress score
        stress_score = (
            jitter_norm * 0.3 +
            shimmer_norm * 0.3 +
            spectral_norm * 0.2 +
            hnr_norm * 0.2
        )
        
        # Map to stress level
        if stress_score > 0.7:
            return "high"
        elif stress_score > 0.4:
            return "medium"
        else:
            return "low"
    
    def record_audio_sample(self, duration=5):
        """Record audio sample for analysis"""
        try:
            with self.microphone as source:
                print(f"Recording for {duration} seconds...")
                audio = self.recognizer.listen(source, timeout=duration, phrase_time_limit=duration)
                return audio
        except Exception as e:
            print(f"Audio recording error: {e}")
            return None
    
    def save_audio_sample(self, audio_data, filename):
        """Save audio sample to file"""
        try:
            with open(filename, 'wb') as f:
                f.write(audio_data.get_wav_data())
            print(f"Audio saved to {filename}")
        except Exception as e:
            print(f"Audio save error: {e}")
    
    def load_audio_sample(self, filename):
        """Load audio sample from file"""
        try:
            with sr.AudioFile(filename) as source:
                audio = self.recognizer.record(source)
                return audio
        except Exception as e:
            print(f"Audio load error: {e}")
            return None
    
    def get_voice_characteristics(self, audio_data):
        """Get detailed voice characteristics"""
        try:
            audio_array = np.frombuffer(audio_data.frame_data, dtype=np.int16)
            audio_float = audio_array.astype(np.float32) / 32768.0
            
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                sf.write(temp_file.name, audio_float, audio_data.sample_rate)
                y, sr = librosa.load(temp_file.name, sr=self.sample_rate)
                os.unlink(temp_file.name)
            
            features = self.extract_voice_features(y, sr)
            stress_indicators = self.extract_stress_indicators(y, sr)
            
            characteristics = {
                'features': features,
                'stress_indicators': stress_indicators,
                'emotion': self.classify_voice_emotion(features),
                'stress_level': self.calculate_stress_level(stress_indicators)
            }
            
            return characteristics
            
        except Exception as e:
            print(f"Voice characteristics analysis error: {e}")
            return None
    
    def cleanup(self):
        """Cleanup resources"""
        self.stop_listening()
        if hasattr(self, 'tts_engine'):
            self.tts_engine.stop()
