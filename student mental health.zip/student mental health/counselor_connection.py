"""
Counselor Connection Module
Handles real-time connection to mental health counselors
"""

import socket
import threading
import json
import time
import random
from datetime import datetime
import tkinter as tk
from tkinter import messagebox

class CounselorConnection:
    def __init__(self):
        self.socket = None
        self.connected = False
        self.counselor_name = None
        self.message_queue = []
        self.connection_thread = None
        
        # Simulated counselor responses for demo purposes
        self.simulated_responses = [
            "I understand you're going through a difficult time. Can you tell me more about what's troubling you?",
            "That sounds really challenging. How long have you been feeling this way?",
            "I'm here to listen and support you. What would help you feel more comfortable right now?",
            "It takes courage to reach out for help. What made you decide to connect with me today?",
            "I can hear the pain in your words. You're not alone in this, and I'm here to help.",
            "Let's work through this together. What's the most important thing you'd like to focus on?",
            "Your feelings are valid, and it's okay to feel overwhelmed sometimes. What support do you need?",
            "I'm glad you're taking care of yourself by reaching out. How can I best support you today?",
            "It sounds like you're carrying a lot right now. What would make you feel more supported?",
            "I'm here for you. What would be most helpful for you to talk about right now?"
        ]
        
        # Crisis response templates
        self.crisis_responses = [
            "I'm very concerned about what you're telling me. Your safety is my top priority right now.",
            "I want you to know that you're not alone, and there are people who care about you deeply.",
            "Please know that your life has value and meaning, even when it doesn't feel that way.",
            "I'm here for you, and I also want to make sure you get the immediate help you need.",
            "Your safety is the most important thing. Let's make sure you're safe right now."
        ]
        
        # Connection status
        self.connection_status = "disconnected"
        self.last_heartbeat = None
        
    def connect(self, counselor_id=None):
        """Connect to a counselor"""
        try:
            # In a real implementation, this would connect to an actual counselor service
            # For demo purposes, we'll simulate a connection
            
            if self.connected:
                return True
            
            # Simulate connection process
            self.connection_status = "connecting"
            
            # Simulate connection delay
            time.sleep(1)
            
            # Set connection as successful
            self.connected = True
            self.connection_status = "connected"
            self.counselor_name = counselor_id or "Dr. Sarah Johnson"
            self.last_heartbeat = datetime.now()
            
            # Start connection monitoring thread
            self.connection_thread = threading.Thread(target=self.connection_monitor, daemon=True)
            self.connection_thread.start()
            
            return True
            
        except Exception as e:
            print(f"Connection error: {e}")
            self.connection_status = "error"
            return False
    
    def disconnect(self):
        """Disconnect from counselor"""
        try:
            self.connected = False
            self.connection_status = "disconnected"
            self.counselor_name = None
            
            if self.socket:
                self.socket.close()
                self.socket = None
            
            return True
            
        except Exception as e:
            print(f"Disconnection error: {e}")
            return False
    
    def send_message(self, message):
        """Send message to counselor"""
        if not self.connected:
            return "Not connected to counselor. Please connect first."
        
        try:
            # Add message to queue
            message_data = {
                'timestamp': datetime.now().isoformat(),
                'message': message,
                'sender': 'user'
            }
            self.message_queue.append(message_data)
            
            # In a real implementation, this would send the message over the network
            # For demo purposes, we'll simulate a response
            
            # Simulate response delay
            time.sleep(1)
            
            # Generate appropriate response
            response = self.generate_counselor_response(message)
            
            # Add response to queue
            response_data = {
                'timestamp': datetime.now().isoformat(),
                'message': response,
                'sender': 'counselor'
            }
            self.message_queue.append(response_data)
            
            return response
            
        except Exception as e:
            print(f"Message sending error: {e}")
            return "Error sending message. Please try again."
    
    def generate_counselor_response(self, user_message):
        """Generate appropriate counselor response"""
        message_lower = user_message.lower()
        
        # Check for crisis indicators
        crisis_keywords = ['suicide', 'kill myself', 'end it all', 'not worth living', 
                          'want to die', 'hurt myself', 'self harm']
        
        if any(keyword in message_lower for keyword in crisis_keywords):
            return self.handle_crisis_response()
        
        # Check for specific emotional states
        if any(word in message_lower for word in ['anxious', 'anxiety', 'worried', 'panic']):
            return self.handle_anxiety_response()
        
        if any(word in message_lower for word in ['depressed', 'sad', 'hopeless', 'empty']):
            return self.handle_depression_response()
        
        if any(word in message_lower for word in ['angry', 'mad', 'furious', 'rage']):
            return self.handle_anger_response()
        
        if any(word in message_lower for word in ['stressed', 'overwhelmed', 'pressure']):
            return self.handle_stress_response()
        
        # Default response
        return random.choice(self.simulated_responses)
    
    def handle_crisis_response(self):
        """Handle crisis situations"""
        crisis_response = random.choice(self.crisis_responses)
        
        # Add crisis resources
        resources = "\n\nCRISIS RESOURCES:\n"
        resources += "• National Suicide Prevention Lifeline: 988\n"
        resources += "• Crisis Text Line: Text HOME to 741741\n"
        resources += "• Emergency Services: 911\n"
        resources += "• You are not alone, and help is available 24/7."
        
        return crisis_response + resources
    
    def handle_anxiety_response(self):
        """Handle anxiety-related messages"""
        anxiety_responses = [
            "I can hear that you're feeling anxious. That's a very common feeling, and you're not alone in experiencing it.",
            "Anxiety can be overwhelming, but there are techniques we can use to help you feel more grounded.",
            "Let's work together to identify what's triggering your anxiety and develop coping strategies.",
            "I'm here to help you through this anxious moment. What grounding techniques have worked for you before?",
            "Anxiety is temporary, even though it doesn't feel that way. Let's focus on what you can control right now."
        ]
        return random.choice(anxiety_responses)
    
    def handle_depression_response(self):
        """Handle depression-related messages"""
        depression_responses = [
            "I can hear that you're feeling depressed. That's a very real and valid experience, and I'm here to support you.",
            "Depression can make everything feel overwhelming, but you're taking an important step by reaching out.",
            "Let's talk about what you're experiencing. Sometimes sharing these feelings can help lighten the load.",
            "I want you to know that depression is treatable, and there are people who want to help you feel better.",
            "You're not alone in this struggle. Let's work together to find ways to support your mental health."
        ]
        return random.choice(depression_responses)
    
    def handle_anger_response(self):
        """Handle anger-related messages"""
        anger_responses = [
            "I can sense that you're feeling angry. That's a completely valid emotion, and it's okay to feel this way.",
            "Anger can be a powerful emotion. Let's explore what's behind these feelings and find healthy ways to express them.",
            "It sounds like something has really upset you. Sometimes it helps to take a step back and breathe before we talk.",
            "I'm here to listen if you want to talk about what's making you angry. Sometimes getting it out can help.",
            "Anger is a natural emotion, but it's important to express it in ways that are healthy for you and others."
        ]
        return random.choice(anger_responses)
    
    def handle_stress_response(self):
        """Handle stress-related messages"""
        stress_responses = [
            "I can hear that you're feeling stressed. That's completely understandable given everything going on.",
            "Stress can really take a toll on us. Let's talk about what's causing you the most stress right now.",
            "It sounds like you have a lot on your plate. Sometimes it helps to break things down into smaller, manageable pieces.",
            "I'm here to help you work through this stress. What would make you feel more in control right now?",
            "Stress is a normal part of life, but when it becomes overwhelming, it's important to reach out for support."
        ]
        return random.choice(stress_responses)
    
    def connection_monitor(self):
        """Monitor connection status"""
        while self.connected:
            try:
                # Check if connection is still alive
                if self.last_heartbeat:
                    time_since_heartbeat = (datetime.now() - self.last_heartbeat).seconds
                    if time_since_heartbeat > 30:  # 30 seconds timeout
                        self.connection_status = "timeout"
                        self.connected = False
                        break
                
                # Simulate heartbeat
                time.sleep(5)
                
            except Exception as e:
                print(f"Connection monitor error: {e}")
                break
    
    def get_connection_status(self):
        """Get current connection status"""
        return self.connection_status
    
    def get_counselor_info(self):
        """Get counselor information"""
        if self.connected:
            return {
                'name': self.counselor_name,
                'status': self.connection_status,
                'connected_since': self.last_heartbeat.isoformat() if self.last_heartbeat else None
            }
        return None
    
    def get_message_history(self):
        """Get message history"""
        return self.message_queue.copy()
    
    def clear_message_history(self):
        """Clear message history"""
        self.message_queue.clear()
    
    def save_conversation(self, filename="counselor_conversation.json"):
        """Save conversation to file"""
        try:
            conversation_data = {
                'counselor_info': self.get_counselor_info(),
                'messages': self.message_queue,
                'saved_at': datetime.now().isoformat()
            }
            
            with open(filename, 'w') as f:
                json.dump(conversation_data, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error saving conversation: {e}")
            return False
    
    def load_conversation(self, filename="counselor_conversation.json"):
        """Load conversation from file"""
        try:
            with open(filename, 'r') as f:
                conversation_data = json.load(f)
            
            self.message_queue = conversation_data.get('messages', [])
            return True
            
        except FileNotFoundError:
            return False
        except Exception as e:
            print(f"Error loading conversation: {e}")
            return False
    
    def get_available_counselors(self):
        """Get list of available counselors (simulated)"""
        return [
            {'id': 'counselor_1', 'name': 'Dr. Sarah Johnson', 'specialty': 'Anxiety & Depression', 'available': True},
            {'id': 'counselor_2', 'name': 'Dr. Michael Chen', 'specialty': 'Trauma & PTSD', 'available': True},
            {'id': 'counselor_3', 'name': 'Dr. Emily Rodriguez', 'specialty': 'Relationship Issues', 'available': False},
            {'id': 'counselor_4', 'name': 'Dr. David Thompson', 'specialty': 'Addiction & Recovery', 'available': True},
            {'id': 'counselor_5', 'name': 'Dr. Lisa Park', 'specialty': 'LGBTQ+ Mental Health', 'available': True}
        ]
    
    def request_counselor(self, counselor_id):
        """Request connection to specific counselor"""
        counselors = self.get_available_counselors()
        counselor = next((c for c in counselors if c['id'] == counselor_id), None)
        
        if not counselor:
            return False, "Counselor not found"
        
        if not counselor['available']:
            return False, "Counselor is not available at this time"
        
        # Connect to counselor
        success = self.connect(counselor_id)
        if success:
            return True, f"Connected to {counselor['name']}"
        else:
            return False, "Failed to connect to counselor"
    
    def send_emergency_alert(self):
        """Send emergency alert to counselor"""
        if not self.connected:
            return False
        
        emergency_message = {
            'type': 'emergency',
            'message': 'User has indicated they may be in crisis',
            'timestamp': datetime.now().isoformat(),
            'priority': 'high'
        }
        
        # In a real implementation, this would send an immediate alert
        # For demo purposes, we'll just log it
        print(f"EMERGENCY ALERT: {emergency_message}")
        
        return True
    
    def get_session_summary(self):
        """Get summary of current session"""
        if not self.message_queue:
            return "No messages in current session"
        
        user_messages = [msg for msg in self.message_queue if msg['sender'] == 'user']
        counselor_messages = [msg for msg in self.message_queue if msg['sender'] == 'counselor']
        
        summary = f"Session Summary:\n"
        summary += f"Duration: {len(self.message_queue)} messages exchanged\n"
        summary += f"User messages: {len(user_messages)}\n"
        summary += f"Counselor responses: {len(counselor_messages)}\n"
        
        if self.last_heartbeat:
            summary += f"Connected since: {self.last_heartbeat.strftime('%H:%M:%S')}\n"
        
        return summary
    
    def cleanup(self):
        """Cleanup resources"""
        self.disconnect()
        if self.connection_thread:
            self.connection_thread.join(timeout=1)
