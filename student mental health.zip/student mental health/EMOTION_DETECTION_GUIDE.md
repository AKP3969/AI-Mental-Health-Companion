# Advanced Text-Based Emotion Detection Guide

## Overview

The AI Mental Health Companion features a sophisticated text-based emotion detection system that uses multiple NLP techniques to accurately identify emotions from text input. This system combines rule-based methods, machine learning, and transformer models to provide comprehensive emotion analysis.

## Features

### 🧠 Multi-Model Architecture
- **Rule-based Detection**: Keyword matching, sentiment analysis, and pattern recognition
- **Machine Learning**: TF-IDF vectorization with logistic regression
- **Transformer Models**: Pre-trained emotion classification models
- **Ensemble Method**: Combines multiple approaches for optimal accuracy
- **Hybrid Approach**: Integrates contextual and linguistic analysis

### 📊 Advanced Analysis
- **Emotion Categories**: Happy, Sad, Angry, Fear, Surprise, Disgust, Neutral
- **Intensity Detection**: Low, Medium, High emotional intensity
- **Confidence Scoring**: Reliability assessment for predictions
- **Contextual Analysis**: Pattern recognition for crisis detection
- **Linguistic Features**: Sentence structure, punctuation, repetition analysis

### 🔍 Specialized Features
- **Crisis Detection**: Automatic identification of crisis situations
- **Negation Handling**: Proper interpretation of negated emotions
- **Intensity Modifiers**: Recognition of emotional intensifiers
- **Emoji Analysis**: Emotion detection from emoji usage
- **Batch Processing**: Efficient processing of multiple texts

## Usage Examples

### Basic Emotion Detection

```python
from emotion_detector import EmotionDetector

# Initialize detector
detector = EmotionDetector(model_type='ensemble')

# Detect emotion
text = "I'm so happy today! This is amazing!"
emotion = detector.detect_emotion(text)
print(f"Emotion: {emotion}")  # Output: happy

# Get detailed analysis
intensity = detector.get_emotion_intensity(text)
confidence = detector.get_emotion_confidence(text)
probabilities = detector.get_emotion_probabilities(text)

print(f"Intensity: {intensity}")
print(f"Confidence: {confidence:.2f}")
print(f"Probabilities: {probabilities}")
```

### Advanced Analysis

```python
# Get comprehensive emotional insights
insights = detector.get_emotional_insights(text)
print(f"Primary emotion: {insights['primary_emotion']}")
print(f"Intensity: {insights['intensity']}")
print(f"Confidence: {insights['confidence']}")
print(f"Recommendations: {insights['recommendations']}")
```

### Batch Processing

```python
# Process multiple texts
texts = [
    "I love this new job!",
    "I hate my life right now",
    "I'm excited about the weekend",
    "I'm worried about the exam"
]

results = detector.batch_detect_emotions(texts)
for result in results:
    print(f"Text: {result['text']}")
    print(f"Emotion: {result['emotion']}")
    print(f"Intensity: {result['intensity']}")
    print(f"Confidence: {result['confidence']:.2f}")
```

### Emotion Statistics

```python
# Analyze emotion distribution
stats = detector.get_emotion_statistics(texts)
print(f"Total texts: {stats['total_texts']}")
print(f"Most common emotion: {stats['most_common_emotion']}")
print(f"Emotion diversity: {stats['emotion_diversity']:.2f}")
print("Emotion distribution:")
for emotion, percentage in stats['emotion_percentages'].items():
    print(f"  {emotion}: {percentage:.1f}%")
```

## Model Types

### 1. Rule-based Detection (`model_type='rule_based'`)
- **Method**: Keyword matching, sentiment analysis, pattern recognition
- **Pros**: Fast, interpretable, works without training data
- **Cons**: Limited accuracy, requires manual rule creation
- **Best for**: Quick analysis, when no training data is available

### 2. Machine Learning (`model_type='ml'`)
- **Method**: TF-IDF vectorization + Logistic Regression
- **Pros**: Good accuracy with training data, fast inference
- **Cons**: Requires labeled training data, limited context understanding
- **Best for**: When you have labeled emotion data for training

### 3. Transformer Models (`model_type='transformers'`)
- **Method**: Pre-trained emotion classification models
- **Pros**: High accuracy, understands context and nuance
- **Cons**: Requires more computational resources, slower
- **Best for**: High-accuracy requirements, complex text analysis

### 4. Ensemble Method (`model_type='ensemble'`)
- **Method**: Combines multiple approaches with weighted voting
- **Pros**: Best overall accuracy, robust to different text types
- **Cons**: More complex, requires more resources
- **Best for**: Production use, when accuracy is critical

### 5. Hybrid Approach (`model_type='hybrid'`)
- **Method**: Integrates rule-based, contextual, and linguistic analysis
- **Pros**: Comprehensive analysis, handles complex cases
- **Cons**: More complex, requires more computational resources
- **Best for**: Research, detailed emotion analysis

## Training Custom Models

### Creating Training Data

```python
# Create emotion dataset
training_data = [
    {"text": "I'm so happy today!", "emotion": "happy"},
    {"text": "I feel really sad", "emotion": "sad"},
    {"text": "I'm angry about this", "emotion": "angry"},
    {"text": "I'm scared of spiders", "emotion": "fear"},
    {"text": "I'm surprised by this", "emotion": "surprise"},
    {"text": "I'm disgusted by this", "emotion": "disgust"},
    {"text": "I feel okay", "emotion": "neutral"}
]

# Save dataset
detector.create_emotion_dataset(training_data, "my_emotion_dataset.json")
```

### Training ML Model

```python
# Load training data
dataset = detector.load_emotion_dataset("my_emotion_dataset.json")

# Train model
success = detector.train_ml_model(dataset, test_size=0.2)
if success:
    print("Model trained successfully!")
```

### Evaluating Model Performance

```python
# Evaluate on test data
test_data = [
    {"text": "I love this!", "emotion": "happy"},
    {"text": "I hate this", "emotion": "angry"},
    {"text": "I'm worried", "emotion": "fear"}
]

results = detector.evaluate_model(test_data)
print(f"Accuracy: {results['accuracy']:.3f}")
print("Classification Report:")
print(results['classification_report'])
```

## Configuration Options

### Model Configuration

```python
# Initialize with specific model type
detector = EmotionDetector(model_type='ensemble')

# Check available methods
info = detector.get_model_info()
print(f"Model type: {info['model_type']}")
print(f"Available methods: {info['available_methods']}")
print(f"Emotion categories: {info['emotion_categories']}")
```

### Custom Emotion Keywords

```python
# The system uses comprehensive emotion keywords by default
# You can extend them by modifying the emotion_keywords dictionary
detector.emotion_keywords['happy']['words'].extend(['ecstatic', 'thrilled', 'elated'])
detector.emotion_keywords['sad']['words'].extend(['devastated', 'heartbroken', 'crushed'])
```

## Crisis Detection

The system includes specialized crisis detection capabilities:

```python
# Crisis detection patterns
crisis_texts = [
    "I want to die",
    "I want to kill myself",
    "I hate my life",
    "Nothing matters anymore",
    "I can't go on like this"
]

for text in crisis_texts:
    emotion = detector.detect_emotion(text)
    context_scores = detector._analyze_context(text)
    print(f"'{text}' -> {emotion}")
    print(f"Context scores: {context_scores}")
```

## Performance Optimization

### Batch Processing
```python
# Process multiple texts efficiently
texts = ["Text 1", "Text 2", "Text 3"]
results = detector.batch_detect_emotions(texts)
```

### Model Comparison
```python
# Compare different model types
test_data = [{"text": "I'm happy", "emotion": "happy"}]
comparison = detector.compare_models(test_data)
for model_type, results in comparison.items():
    print(f"{model_type}: {results['accuracy']:.3f}")
```

## Error Handling

```python
try:
    emotion = detector.detect_emotion(text)
except Exception as e:
    print(f"Error in emotion detection: {e}")
    # Fallback to neutral emotion
    emotion = 'neutral'
```

## Best Practices

1. **Choose the right model type** for your use case
2. **Use ensemble method** for production applications
3. **Train custom models** with domain-specific data
4. **Handle errors gracefully** with fallback options
5. **Monitor performance** and retrain models as needed
6. **Use batch processing** for multiple texts
7. **Validate results** with human evaluation

## Troubleshooting

### Common Issues

1. **Low accuracy**: Try different model types or train with more data
2. **Slow performance**: Use rule-based or ML models instead of transformers
3. **Memory issues**: Process texts in smaller batches
4. **Import errors**: Install missing dependencies from requirements.txt

### Debugging

```python
# Get detailed model information
info = detector.get_model_info()
print(f"Available methods: {info['available_methods']}")

# Test individual components
sentiment_scores = detector.get_sentiment_scores(text)
keyword_scores = detector.get_keyword_scores(text)
emoji_scores = detector.get_emoji_scores(text)
context_scores = detector._analyze_context(text)
```

## API Reference

### Main Methods

- `detect_emotion(text)`: Detect primary emotion from text
- `get_emotion_intensity(text)`: Get emotional intensity level
- `get_emotion_confidence(text)`: Get confidence score
- `get_emotion_probabilities(text)`: Get probability distribution
- `get_emotional_insights(text)`: Get comprehensive analysis
- `batch_detect_emotions(texts)`: Process multiple texts
- `get_emotion_statistics(texts)`: Analyze emotion distribution

### Training Methods

- `train_ml_model(training_data)`: Train machine learning model
- `evaluate_model(test_data)`: Evaluate model performance
- `create_emotion_dataset(data)`: Create training dataset
- `load_emotion_dataset(path)`: Load dataset from file

### Utility Methods

- `compare_models(test_data)`: Compare different model types
- `get_model_info()`: Get model configuration information
- `_analyze_context(text)`: Analyze contextual patterns
- `_analyze_linguistic_features(text)`: Analyze linguistic features

## Examples

See `test_emotion_detection.py` for comprehensive examples of all features.

## Support

For questions or issues with the emotion detection system, please refer to the main README.md or create an issue in the project repository.
