"""
Mental Health Chatbot Module
Provides conversational AI responses for mental health support
"""

import json
import random
from datetime import datetime
import re

class MentalHealthChatbot:
    def __init__(self):
        self.responses = self.load_responses()
        self.conversation_context = []
        self.user_profile = {}
        self.crisis_keywords = [
            'suicide', 'kill myself', 'end it all', 'not worth living',
            'want to die', 'hurt myself', 'self harm', 'cut myself'
        ]
        
        # Load conversation patterns
        self.patterns = self.load_patterns()
        
        # Emergency contacts
        self.emergency_contacts = {
            'crisis_text': 'Text HOME to 741741',
            'crisis_call': 'Call 988 (Suicide & Crisis Lifeline)',
            'emergency': 'Call 911 for immediate emergency'
        }
    
    def load_responses(self):
        """Load response templates for different emotions and situations"""
        return {
            'happy': [
                "I'm so glad to hear you're feeling happy! What's bringing you joy today?",
                "That's wonderful! It's great to see you in such a positive mood. Would you like to share what's making you feel this way?",
                "Your happiness is contagious! It's important to celebrate these good moments. What can we do to keep this positive energy going?",
                "I love hearing about your happiness! Remember to savor these moments and maybe even write them down in your journal."
            ],
            'sad': [
                "I'm sorry you're feeling sad. It's okay to have these feelings. Would you like to talk about what's on your mind?",
                "I can hear that you're going through a tough time. Remember that it's okay to feel sad, and you don't have to go through this alone.",
                "Your feelings are valid, and I'm here to listen. Sometimes talking about what's making us sad can help us process it better.",
                "I'm here for you. Sometimes when we're sad, it helps to know that someone cares. What would make you feel a little better right now?"
            ],
            'angry': [
                "I can sense you're feeling angry. That's a completely valid emotion. Would you like to talk about what's making you feel this way?",
                "It sounds like something has really upset you. Sometimes it helps to take a few deep breaths and then talk about what's bothering you.",
                "I'm here to listen if you want to vent about what's making you angry. Sometimes getting it out can help us feel better.",
                "Anger is a natural emotion, but it's important to express it in healthy ways. What's causing you to feel this way?"
            ],
            'fear': [
                "I can hear the fear in your words. It's completely normal to feel afraid sometimes. What are you most worried about?",
                "Fear can be overwhelming, but remember that you're safe right now. Would you like to talk about what's making you feel afraid?",
                "I'm here to help you work through these fears. Sometimes talking about them can make them feel less scary.",
                "It's okay to feel afraid. What would help you feel more secure right now?"
            ],
            'anxious': [
                "I can sense you're feeling anxious. That's a very common feeling, and you're not alone in experiencing it.",
                "Anxiety can be really overwhelming. Let's try some breathing exercises together. Would that help?",
                "I'm here to help you through this anxious moment. What's making you feel most worried right now?",
                "Remember that anxiety is temporary, even though it doesn't feel that way. What grounding techniques have worked for you before?"
            ],
            'stressed': [
                "I can hear that you're feeling stressed. That's completely understandable given everything going on.",
                "Stress can really take a toll on us. What's causing you the most stress right now?",
                "It sounds like you have a lot on your plate. Sometimes it helps to break things down into smaller, manageable pieces.",
                "I'm here to help you work through this stress. What would make you feel more in control right now?"
            ],
            'overwhelmed': [
                "It sounds like you're feeling overwhelmed. That's a very common feeling when we have a lot going on.",
                "I can hear that you're carrying a lot right now. It's okay to feel overwhelmed - it's a sign that you're human.",
                "When we feel overwhelmed, sometimes it helps to focus on just one thing at a time. What's the most important thing to address right now?",
                "You don't have to handle everything alone. What support do you need right now?"
            ],
            'neutral': [
                "How are you feeling today? I'm here to listen and support you.",
                "I'm here for you. What's on your mind?",
                "How can I help you today? I'm here to listen and provide support.",
                "What would you like to talk about? I'm here to help in any way I can."
            ],
            'crisis': [
                "I'm very concerned about what you're telling me. Your safety is the most important thing right now.",
                "I want you to know that you're not alone, and there are people who care about you and want to help.",
                "Please reach out to a crisis counselor or emergency services right away. Your life has value and meaning.",
                "I'm here for you, but I also want to make sure you get the immediate help you need."
            ]
        }
    
    def load_patterns(self):
        """Load conversation patterns for better responses"""
        return {
            'greeting': [
                r'\b(hi|hello|hey|good morning|good afternoon|good evening)\b',
                r'\b(how are you|how\'s it going|what\'s up)\b'
            ],
            'goodbye': [
                r'\b(bye|goodbye|see you|talk to you later|gotta go)\b',
                r'\b(thanks|thank you|that\'s all|done)\b'
            ],
            'help_request': [
                r'\b(help|need help|can you help|support)\b',
                r'\b(what should i do|i don\'t know|confused)\b'
            ],
            'feeling_expression': [
                r'\b(i feel|i\'m feeling|feeling|feel)\b',
                r'\b(i am|i\'m|am)\b.*\b(sad|happy|angry|scared|anxious|stressed|overwhelmed)\b'
            ],
            'crisis_indicators': [
                r'\b(suicide|kill myself|end it all|not worth living|want to die)\b',
                r'\b(hurt myself|self harm|cut myself|end my life)\b'
            ]
        }
    
    def get_response(self, user_message, text_emotion=None, face_emotion=None):
        """Generate appropriate response based on user message and emotions"""
        # Clean and process the message
        message = user_message.lower().strip()
        
        # Check for crisis indicators
        if self.detect_crisis(message):
            return self.handle_crisis_response()
        
        # Determine primary emotion
        primary_emotion = self.determine_primary_emotion(message, text_emotion, face_emotion)
        
        # Get contextual response
        response = self.generate_contextual_response(message, primary_emotion)
        
        # Update conversation context
        self.update_conversation_context(user_message, response, primary_emotion)
        
        return response
    
    def detect_crisis(self, message):
        """Detect if the message contains crisis indicators"""
        for keyword in self.crisis_keywords:
            if keyword in message:
                return True
        return False
    
    def handle_crisis_response(self):
        """Handle crisis situations with appropriate resources"""
        crisis_response = random.choice(self.responses['crisis'])
        
        # Add emergency resources
        resources = "\n\nIf you're in immediate danger, please call 911 or go to your nearest emergency room.\n"
        resources += f"Crisis Text Line: {self.emergency_contacts['crisis_text']}\n"
        resources += f"Suicide & Crisis Lifeline: {self.emergency_contacts['crisis_call']}\n"
        resources += "You are not alone, and there are people who want to help you."
        
        return crisis_response + resources
    
    def determine_primary_emotion(self, message, text_emotion, face_emotion):
        """Determine the primary emotion from multiple sources"""
        # Priority: text emotion > face emotion > pattern matching
        if text_emotion and text_emotion != 'neutral':
            return text_emotion
        
        if face_emotion and face_emotion != 'neutral':
            return face_emotion
        
        # Pattern matching for emotion detection
        emotion_patterns = {
            'sad': [r'\b(sad|depressed|down|blue|miserable|unhappy|gloomy)\b'],
            'happy': [r'\b(happy|joy|excited|cheerful|delighted|pleased|great|wonderful)\b'],
            'angry': [r'\b(angry|mad|furious|irritated|annoyed|rage|frustrated|livid)\b'],
            'fear': [r'\b(afraid|scared|fearful|terrified|anxious|worried|nervous|panic)\b'],
            'anxious': [r'\b(anxious|worried|nervous|panic|stressed|overwhelmed)\b'],
            'stressed': [r'\b(stressed|overwhelmed|pressure|too much|can\'t handle)\b']
        }
        
        for emotion, patterns in emotion_patterns.items():
            for pattern in patterns:
                if re.search(pattern, message):
                    return emotion
        
        return 'neutral'
    
    def generate_contextual_response(self, message, emotion):
        """Generate contextual response based on emotion and message content"""
        # Check for specific patterns first
        if self.matches_pattern(message, 'greeting'):
            return self.handle_greeting()
        
        if self.matches_pattern(message, 'goodbye'):
            return self.handle_goodbye()
        
        if self.matches_pattern(message, 'help_request'):
            return self.handle_help_request()
        
        # Get emotion-based response
        if emotion in self.responses:
            base_response = random.choice(self.responses[emotion])
        else:
            base_response = random.choice(self.responses['neutral'])
        
        # Add personalized elements
        personalized_response = self.personalize_response(base_response, message, emotion)
        
        return personalized_response
    
    def matches_pattern(self, message, pattern_type):
        """Check if message matches a specific pattern"""
        if pattern_type in self.patterns:
            for pattern in self.patterns[pattern_type]:
                if re.search(pattern, message, re.IGNORECASE):
                    return True
        return False
    
    def handle_greeting(self):
        """Handle greeting messages"""
        greetings = [
            "Hello! I'm here to support you. How are you feeling today?",
            "Hi there! I'm your AI mental health companion. What's on your mind?",
            "Hello! I'm here to listen and help. How can I support you today?",
            "Hi! I'm glad you're here. How are you doing today?"
        ]
        return random.choice(greetings)
    
    def handle_goodbye(self):
        """Handle goodbye messages"""
        goodbyes = [
            "Take care of yourself. I'm always here when you need to talk.",
            "Goodbye! Remember to be kind to yourself today.",
            "Take care! Don't hesitate to reach out if you need support.",
            "See you later! Remember that you're doing great, and I'm here whenever you need me."
        ]
        return random.choice(goodbyes)
    
    def handle_help_request(self):
        """Handle help requests"""
        help_responses = [
            "I'm here to help! What specific support do you need right now?",
            "I'm here to listen and provide support. What's troubling you?",
            "I'm here for you. What would be most helpful right now?",
            "I'm here to help in any way I can. What do you need support with?"
        ]
        return random.choice(help_responses)
    
    def personalize_response(self, base_response, message, emotion):
        """Personalize response based on conversation context and user profile"""
        # Add context from recent conversation
        if self.conversation_context:
            recent_topics = self.extract_recent_topics()
            if recent_topics:
                # Reference recent topics if relevant
                if any(topic in message for topic in recent_topics):
                    base_response += f" I remember you mentioned {recent_topics[0]} earlier. "
        
        # Add emotion-specific suggestions
        suggestions = self.get_emotion_suggestions(emotion)
        if suggestions:
            base_response += f" {suggestions}"
        
        return base_response
    
    def extract_recent_topics(self):
        """Extract topics from recent conversation"""
        topics = []
        for entry in self.conversation_context[-3:]:  # Last 3 exchanges
            message = entry['user_message'].lower()
            # Simple topic extraction (can be enhanced)
            if 'work' in message or 'job' in message:
                topics.append('work')
            elif 'family' in message or 'parents' in message:
                topics.append('family')
            elif 'school' in message or 'study' in message:
                topics.append('school')
            elif 'relationship' in message or 'partner' in message:
                topics.append('relationships')
        return topics
    
    def get_emotion_suggestions(self, emotion):
        """Get suggestions based on detected emotion"""
        suggestions = {
            'sad': "Would you like to try some gentle self-care activities or talk about what's making you feel this way?",
            'angry': "Sometimes it helps to take a few deep breaths or do some physical activity. What would help you right now?",
            'anxious': "Would you like to try some breathing exercises or grounding techniques?",
            'stressed': "It might help to break things down into smaller steps or take a short break. What would be most helpful?",
            'overwhelmed': "Let's focus on just one thing at a time. What's the most important thing to address right now?",
            'happy': "It's wonderful to see you feeling this way! What's bringing you joy today?"
        }
        return suggestions.get(emotion, "")
    
    def update_conversation_context(self, user_message, ai_response, emotion):
        """Update conversation context for better responses"""
        context_entry = {
            'timestamp': datetime.now().isoformat(),
            'user_message': user_message,
            'ai_response': ai_response,
            'emotion': emotion
        }
        
        self.conversation_context.append(context_entry)
        
        # Keep only last 10 exchanges
        if len(self.conversation_context) > 10:
            self.conversation_context = self.conversation_context[-10:]
    
    def get_conversation_summary(self):
        """Get summary of recent conversation"""
        if not self.conversation_context:
            return "No recent conversation."
        
        emotions = [entry['emotion'] for entry in self.conversation_context]
        emotion_counts = {}
        for emotion in emotions:
            emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
        
        most_common_emotion = max(emotion_counts, key=emotion_counts.get)
        
        summary = f"Recent conversation shows {most_common_emotion} as the predominant emotion. "
        summary += f"Total exchanges: {len(self.conversation_context)}"
        
        return summary
    
    def save_conversation_history(self, filename="conversation_history.json"):
        """Save conversation history to file"""
        try:
            with open(filename, 'w') as f:
                json.dump(self.conversation_context, f, indent=2)
        except Exception as e:
            print(f"Error saving conversation history: {e}")
    
    def load_conversation_history(self, filename="conversation_history.json"):
        """Load conversation history from file"""
        try:
            with open(filename, 'r') as f:
                self.conversation_context = json.load(f)
        except FileNotFoundError:
            self.conversation_context = []
        except Exception as e:
            print(f"Error loading conversation history: {e}")
            self.conversation_context = []
    
    def get_emotional_insights(self):
        """Get insights about user's emotional patterns"""
        if not self.conversation_context:
            return "No conversation data available for analysis."
        
        emotions = [entry['emotion'] for entry in self.conversation_context]
        emotion_counts = {}
        for emotion in emotions:
            emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
        
        total_emotions = len(emotions)
        insights = []
        
        for emotion, count in emotion_counts.items():
            percentage = (count / total_emotions) * 100
            insights.append(f"{emotion}: {percentage:.1f}%")
        
        return "Emotional patterns: " + ", ".join(insights)
    
    def reset_conversation(self):
        """Reset conversation context"""
        self.conversation_context = []
        print("Conversation context reset.")
    
    def get_support_resources(self):
        """Get mental health support resources"""
        resources = {
            'crisis': {
                'text': 'Text HOME to 741741',
                'call': 'Call 988 (Suicide & Crisis Lifeline)',
                'emergency': 'Call 911 for immediate emergency'
            },
            'general': {
                'therapy': 'Consider talking to a mental health professional',
                'support_groups': 'Look for local or online support groups',
                'self_care': 'Practice regular self-care activities',
                'meditation': 'Try meditation or mindfulness practices'
            }
        }
        return resources
