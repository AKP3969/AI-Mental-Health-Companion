#!/usr/bin/env python3
"""
AI Mental Health Companion
A comprehensive mental health support system with emotion detection,
face recognition, and real-time counselor connection.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
import queue
import json
import os
from datetime import datetime
import cv2
import numpy as np
from PIL import Image, ImageTk
import random

# Import our custom modules
from emotion_detector import EmotionDetector
from face_analyzer import FaceAnalyzer
from speech_processor import SpeechProcessor
from chatbot import MentalHealthChatbot
from relaxation_exercises import RelaxationExercises
from counselor_connection import CounselorConnection
from data_manager import DataManager

class MentalHealthCompanion:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("AI Mental Health Companion")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        # Initialize components
        self.emotion_detector = EmotionDetector()
        self.face_analyzer = FaceAnalyzer()
        self.speech_processor = SpeechProcessor()
        self.chatbot = MentalHealthChatbot()
        self.relaxation_exercises = RelaxationExercises()
        self.counselor_connection = CounselorConnection()
        self.data_manager = DataManager()
        
        # State variables
        self.camera_active = False
        self.microphone_active = False
        self.current_emotion = "neutral"
        self.conversation_history = []
        
        # Create GUI
        self.create_gui()
        
        # Start background processes
        self.start_background_processes()
    
    def create_gui(self):
        """Create the main GUI interface"""
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Left panel - Camera and Face Analysis
        left_panel = ttk.LabelFrame(main_frame, text="Face Analysis", padding="10")
        left_panel.grid(row=0, column=0, rowspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        
        # Camera display
        self.camera_label = ttk.Label(left_panel, text="Camera Feed", background="black")
        self.camera_label.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Camera controls
        camera_controls = ttk.Frame(left_panel)
        camera_controls.pack(fill=tk.X, pady=(0, 10))
        
        self.camera_button = ttk.Button(camera_controls, text="Start Camera", 
                                      command=self.toggle_camera)
        self.camera_button.pack(side=tk.LEFT, padx=(0, 5))
        
        self.mic_button = ttk.Button(camera_controls, text="Start Mic", 
                                   command=self.toggle_microphone)
        self.mic_button.pack(side=tk.LEFT)
        
        # Emotion display
        emotion_frame = ttk.LabelFrame(left_panel, text="Current Emotion", padding="5")
        emotion_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.emotion_label = ttk.Label(emotion_frame, text="Neutral", 
                                     font=("Arial", 16, "bold"), foreground="blue")
        self.emotion_label.pack()
        
        # Stress level indicator
        stress_frame = ttk.LabelFrame(left_panel, text="Stress Level", padding="5")
        stress_frame.pack(fill=tk.X)
        
        self.stress_progress = ttk.Progressbar(stress_frame, mode='determinate')
        self.stress_progress.pack(fill=tk.X)
        
        self.stress_label = ttk.Label(stress_frame, text="Low")
        self.stress_label.pack()
        
        # Right panel - Chat and Features
        right_panel = ttk.LabelFrame(main_frame, text="Mental Health Support", padding="10")
        right_panel.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        right_panel.columnconfigure(0, weight=1)
        right_panel.rowconfigure(1, weight=1)
        
        # Tab notebook
        self.notebook = ttk.Notebook(right_panel)
        self.notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        # Chat tab
        self.create_chat_tab()
        
        # Relaxation tab
        self.create_relaxation_tab()
        
        # Counselor tab
        self.create_counselor_tab()
        
        # Progress tab
        self.create_progress_tab()
        
        # Input area
        input_frame = ttk.Frame(right_panel)
        input_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(10, 0))
        input_frame.columnconfigure(0, weight=1)
        
        self.message_entry = ttk.Entry(input_frame, font=("Arial", 12))
        self.message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        self.message_entry.bind('<Return>', self.send_message)
        
        self.send_button = ttk.Button(input_frame, text="Send", command=self.send_message)
        self.send_button.pack(side=tk.RIGHT)
    
    def create_chat_tab(self):
        """Create the chat interface tab"""
        chat_frame = ttk.Frame(self.notebook)
        self.notebook.add(chat_frame, text="Chat")
        
        # Chat display
        self.chat_display = scrolledtext.ScrolledText(chat_frame, height=20, 
                                                    font=("Arial", 11), wrap=tk.WORD)
        self.chat_display.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Quick response buttons
        quick_frame = ttk.LabelFrame(chat_frame, text="Quick Responses", padding="5")
        quick_frame.pack(fill=tk.X)
        
        quick_responses = [
            "I'm feeling anxious", "I'm stressed", "I need help", 
            "I'm feeling sad", "I want to talk", "I'm feeling overwhelmed"
        ]
        
        for i, response in enumerate(quick_responses):
            btn = ttk.Button(quick_frame, text=response, 
                           command=lambda r=response: self.send_quick_message(r))
            btn.grid(row=i//3, column=i%3, padx=2, pady=2, sticky=tk.W+tk.E)
    
    def create_relaxation_tab(self):
        """Create the relaxation exercises tab"""
        relax_frame = ttk.Frame(self.notebook)
        self.notebook.add(relax_frame, text="Relaxation")
        
        # Breathing exercise
        breathing_frame = ttk.LabelFrame(relax_frame, text="Breathing Exercise", padding="10")
        breathing_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.breathing_canvas = tk.Canvas(breathing_frame, height=200, bg='lightblue')
        self.breathing_canvas.pack(fill=tk.X, pady=(0, 10))
        
        self.breathing_button = ttk.Button(breathing_frame, text="Start Breathing Exercise",
                                         command=self.start_breathing_exercise)
        self.breathing_button.pack()
        
        # Music section
        music_frame = ttk.LabelFrame(relax_frame, text="Relaxing Music", padding="10")
        music_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.music_button = ttk.Button(music_frame, text="Play Relaxing Music",
                                     command=self.play_relaxing_music)
        self.music_button.pack()
        
        # Journaling section
        journal_frame = ttk.LabelFrame(relax_frame, text="Journaling", padding="10")
        journal_frame.pack(fill=tk.BOTH, expand=True)
        
        self.journal_text = scrolledtext.ScrolledText(journal_frame, height=8)
        self.journal_text.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        journal_buttons = ttk.Frame(journal_frame)
        journal_buttons.pack(fill=tk.X)
        
        ttk.Button(journal_buttons, text="Save Entry", 
                  command=self.save_journal_entry).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(journal_buttons, text="Clear", 
                  command=self.clear_journal).pack(side=tk.LEFT)
    
    def create_counselor_tab(self):
        """Create the counselor connection tab"""
        counselor_frame = ttk.Frame(self.notebook)
        self.notebook.add(counselor_frame, text="Counselor")
        
        # Connection status
        status_frame = ttk.LabelFrame(counselor_frame, text="Connection Status", padding="10")
        status_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.connection_status = ttk.Label(status_frame, text="Disconnected", 
                                         foreground="red")
        self.connection_status.pack()
        
        # Connect button
        self.connect_button = ttk.Button(status_frame, text="Connect to Counselor",
                                       command=self.connect_to_counselor)
        self.connect_button.pack(pady=(10, 0))
        
        # Counselor chat
        counselor_chat_frame = ttk.LabelFrame(counselor_frame, text="Counselor Chat", padding="10")
        counselor_chat_frame.pack(fill=tk.BOTH, expand=True)
        
        self.counselor_display = scrolledtext.ScrolledText(counselor_chat_frame, height=15)
        self.counselor_display.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Counselor input
        counselor_input_frame = ttk.Frame(counselor_chat_frame)
        counselor_input_frame.pack(fill=tk.X)
        counselor_input_frame.columnconfigure(0, weight=1)
        
        self.counselor_entry = ttk.Entry(counselor_input_frame)
        self.counselor_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        self.counselor_entry.bind('<Return>', self.send_counselor_message)
        
        ttk.Button(counselor_input_frame, text="Send", 
                  command=self.send_counselor_message).pack(side=tk.RIGHT)
    
    def create_progress_tab(self):
        """Create the progress tracking tab"""
        progress_frame = ttk.Frame(self.notebook)
        self.notebook.add(progress_frame, text="Progress")
        
        # Mood tracking
        mood_frame = ttk.LabelFrame(progress_frame, text="Mood Tracking", padding="10")
        mood_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(mood_frame, text="How are you feeling today?").pack(anchor=tk.W)
        
        mood_scale = ttk.Scale(mood_frame, from_=1, to=10, orient=tk.HORIZONTAL)
        mood_scale.pack(fill=tk.X, pady=(5, 10))
        
        ttk.Button(mood_frame, text="Record Mood", 
                  command=lambda: self.record_mood(mood_scale.get())).pack()
        
        # Progress chart
        chart_frame = ttk.LabelFrame(progress_frame, text="Progress Chart", padding="10")
        chart_frame.pack(fill=tk.BOTH, expand=True)
        
        self.progress_canvas = tk.Canvas(chart_frame, bg='white')
        self.progress_canvas.pack(fill=tk.BOTH, expand=True)
    
    def start_background_processes(self):
        """Start background processes for camera and emotion detection"""
        self.camera_thread = threading.Thread(target=self.camera_loop, daemon=True)
        self.camera_thread.start()
        
        self.emotion_thread = threading.Thread(target=self.emotion_analysis_loop, daemon=True)
        self.emotion_thread.start()
    
    def camera_loop(self):
        """Camera processing loop"""
        cap = cv2.VideoCapture(0)
        
        while True:
            if self.camera_active:
                ret, frame = cap.read()
                if ret:
                    # Process frame for face detection and emotion analysis
                    processed_frame = self.face_analyzer.process_frame(frame)
                    
                    # Convert to PhotoImage for tkinter
                    frame_rgb = cv2.cvtColor(processed_frame, cv2.COLOR_BGR2RGB)
                    frame_pil = Image.fromarray(frame_rgb)
                    frame_tk = ImageTk.PhotoImage(frame_pil)
                    
                    # Update camera display
                    self.root.after(0, self.update_camera_display, frame_tk)
            
            cv2.waitKey(1)
        
        cap.release()
    
    def emotion_analysis_loop(self):
        """Background emotion analysis loop"""
        while True:
            if self.camera_active:
                # Get current emotion from face analysis
                emotion = self.face_analyzer.get_current_emotion()
                if emotion:
                    self.current_emotion = emotion
                    self.root.after(0, self.update_emotion_display, emotion)
            
            threading.Event().wait(1)  # Update every second
    
    def update_camera_display(self, frame_tk):
        """Update camera display in GUI"""
        self.camera_label.configure(image=frame_tk)
        self.camera_label.image = frame_tk  # Keep a reference
    
    def update_emotion_display(self, emotion):
        """Update emotion display in GUI"""
        self.emotion_label.configure(text=emotion.title())
        
        # Update stress level based on emotion
        stress_levels = {
            'happy': 20, 'neutral': 40, 'sad': 60, 
            'angry': 80, 'fear': 70, 'surprise': 50
        }
        
        stress = stress_levels.get(emotion, 40)
        self.stress_progress['value'] = stress
        
        stress_labels = {20: 'Low', 40: 'Medium', 60: 'High', 80: 'Very High'}
        self.stress_label.configure(text=stress_labels.get(stress, 'Medium'))
    
    def toggle_camera(self):
        """Toggle camera on/off"""
        self.camera_active = not self.camera_active
        if self.camera_active:
            self.camera_button.configure(text="Stop Camera")
        else:
            self.camera_button.configure(text="Start Camera")
    
    def toggle_microphone(self):
        """Toggle microphone on/off"""
        self.microphone_active = not self.microphone_active
        if self.microphone_active:
            self.mic_button.configure(text="Stop Mic")
            # Start speech processing
            threading.Thread(target=self.speech_processing_loop, daemon=True).start()
        else:
            self.mic_button.configure(text="Start Mic")
    
    def speech_processing_loop(self):
        """Process speech input"""
        while self.microphone_active:
            try:
                text = self.speech_processor.listen()
                if text:
                    self.root.after(0, self.process_speech_input, text)
            except Exception as e:
                print(f"Speech processing error: {e}")
    
    def process_speech_input(self, text):
        """Process speech input and update chat"""
        self.message_entry.delete(0, tk.END)
        self.message_entry.insert(0, text)
        self.send_message()
    
    def send_message(self, event=None):
        """Send message to chatbot"""
        message = self.message_entry.get().strip()
        if not message:
            return
        
        # Add user message to chat
        self.add_to_chat("You", message)
        
        # Process with emotion detection
        emotion = self.emotion_detector.detect_emotion(message)
        
        # Get response from chatbot
        response = self.chatbot.get_response(message, emotion, self.current_emotion)
        
        # Add bot response to chat
        self.add_to_chat("AI Companion", response)
        
        # Save conversation
        self.conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'user_message': message,
            'emotion': emotion,
            'ai_response': response
        })
        
        # Clear input
        self.message_entry.delete(0, tk.END)
    
    def send_quick_message(self, message):
        """Send quick response message"""
        self.message_entry.delete(0, tk.END)
        self.message_entry.insert(0, message)
        self.send_message()
    
    def add_to_chat(self, sender, message):
        """Add message to chat display"""
        timestamp = datetime.now().strftime("%H:%M")
        self.chat_display.insert(tk.END, f"[{timestamp}] {sender}: {message}\n\n")
        self.chat_display.see(tk.END)
    
    def start_breathing_exercise(self):
        """Start breathing exercise"""
        self.relaxation_exercises.start_breathing_exercise(self.breathing_canvas)
    
    def play_relaxing_music(self):
        """Play relaxing music"""
        self.relaxation_exercises.play_relaxing_music()
    
    def save_journal_entry(self):
        """Save journal entry"""
        entry = self.journal_text.get("1.0", tk.END).strip()
        if entry:
            self.data_manager.save_journal_entry(entry)
            messagebox.showinfo("Success", "Journal entry saved!")
    
    def clear_journal(self):
        """Clear journal text"""
        self.journal_text.delete("1.0", tk.END)
    
    def connect_to_counselor(self):
        """Connect to counselor"""
        if self.counselor_connection.connect():
            self.connection_status.configure(text="Connected", foreground="green")
            self.connect_button.configure(text="Disconnect", 
                                        command=self.disconnect_from_counselor)
        else:
            messagebox.showerror("Error", "Failed to connect to counselor")
    
    def disconnect_from_counselor(self):
        """Disconnect from counselor"""
        self.counselor_connection.disconnect()
        self.connection_status.configure(text="Disconnected", foreground="red")
        self.connect_button.configure(text="Connect to Counselor",
                                    command=self.connect_to_counselor)
    
    def send_counselor_message(self, event=None):
        """Send message to counselor"""
        message = self.counselor_entry.get().strip()
        if not message:
            return
        
        self.counselor_display.insert(tk.END, f"You: {message}\n")
        self.counselor_entry.delete(0, tk.END)
        
        # Simulate counselor response
        response = self.counselor_connection.send_message(message)
        self.counselor_display.insert(tk.END, f"Counselor: {response}\n\n")
        self.counselor_display.see(tk.END)
    
    def record_mood(self, mood_value):
        """Record mood value"""
        self.data_manager.record_mood(mood_value)
        messagebox.showinfo("Success", f"Mood recorded: {mood_value}/10")
    
    def run(self):
        """Start the application"""
        self.root.mainloop()

if __name__ == "__main__":
    app = MentalHealthCompanion()
    app.run()
